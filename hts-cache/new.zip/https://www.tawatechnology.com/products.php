<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Products | Tawa Technology | Advocate Diary, Micro Finance &amp; Custom Business Apps</title>
  <meta name="description" content="Explore Tawa Technology products including Advocate Diary and Micro Finance / Society Management solutions. Request a demo or discuss custom modules for your business." />
  <meta name="theme-color" content="#003399" />

  <!-- Open Graph (basic, reusable) -->
  <meta property="og:title" content="Products | Tawa Technology | Advocate Diary, Micro Finance &amp; Custom Business Apps" />
  <meta property="og:description" content="Explore Tawa Technology products including Advocate Diary and Micro Finance / Society Management solutions. Request a demo or discuss custom modules for your business." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://www.tawatechnology.com/" />
  <meta property="og:image" content="assets/img/hero-placeholder.jpg" />

  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Poppins:wght@600;700;800&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="assets/css/style.css" />
</head>
<body>
  <a class="skip-link" href="#main-content">Skip to content</a>

  <!-- Top Utility Bar -->
  <div class="topbar topbar--enhanced">
    <div class="container topbar__inner">
      <div class="topbar__left">
        <span class="topbar__item">📍 Nagpur, India</span>
        <a class="topbar__item" href="tel:+918799996171">📞 +91 8799996171</a>
        <a class="topbar__item" href="mailto:info@tawatechnology.com">✉️ info@tawatechnology.com</a>
      </div>
      <div class="topbar__right">
        <a class="topbar__pill" href="contact.php">Enquiry Form</a>
        <a class="topbar__pill topbar__pill--whatsapp" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">WhatsApp</a>
      </div>
    </div>
  </div>

  <!-- Main Header -->
  <header class="site-header" id="site-header">
    <div class="container header__inner">
      <a href="index.php" class="brand" aria-label="Tawa Technology home">
        <img src="assets/img/logo.webp" alt="Tawa Technology logo" class="brand__logo" />
        <div class="brand__text">
          <span class="brand__name">Tawa Technology</span>
          <span class="brand__tagline">Empowering Businesses &amp; Students</span>
        </div>
      </a>

      <button
        class="nav-toggle"
        id="navToggle"
        aria-expanded="false"
        aria-controls="primaryNav"
        aria-label="Open navigation menu"
      >
        <span></span>
        <span></span>
        <span></span>
      </button>

      <nav class="primary-nav" id="primaryNav" aria-label="Primary navigation">
        <ul class="menu">
          <li><a class="" href="index.php">Home</a></li>

          <li><a class="" href="software.php">Software Solutions</a></li>

          <!-- Dropdown-ready item -->
          <li class="has-dropdown">
            <button class="menu-btn is-active" type="button" aria-expanded="false">
              Products
              <span class="caret" aria-hidden="true">▾</span>
            </button>
            <div class="dropdown" role="menu" aria-label="Products submenu">
              <a href="products.php">All Products</a>
              <a href="products.php#advocate-diary">Advocate Diary</a>
              <a href="products.php#micro-finance">Micro Finance</a>
              <a href="products.php#custom-apps">Custom Business Apps</a>
            </div>
          </li>

          <li class="has-dropdown">
            <button class="menu-btn " type="button" aria-expanded="false">
              Training
              <span class="caret" aria-hidden="true">▾</span>
            </button>
            <div class="dropdown" role="menu" aria-label="Training submenu">
              <a href="training.php">All Courses</a>
              <a href="training.php#java-full-stack">Java Full Stack</a>
              <a href="training.php#core-java">Core Java</a>
              <a href="training.php#sql-powerbi">SQL / Power BI</a>
              <a href="training.php#web-development">Web Development</a>
            </div>
          </li>

          <li><a class="" href="case-studies.php">Case Studies</a></li>
          <li><a class="" href="about.php">About</a></li>
          <li><a class="" href="blog.php">Resources</a></li>
          <li><a class="" href="contact.php">Contact</a></li>
        </ul>

        <div class="nav-cta nav-cta--desktop">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">
            Call / WhatsApp Now
          </a>
        </div>
      </nav>
    </div>
  </header>
<main id="main-content">
  <!-- Hero -->
  <section class="section hero hero--inner">
    <div class="container hero__grid">
      <div class="hero__content">
        <p class="eyebrow">Products</p>
        <h1>Domain-Focused Products + Custom Modules for Real Business Workflows</h1>
        <p class="hero__lead">
          Tawa Technology builds practical products and ready solution modules that help organizations digitize operations faster.
          Explore our products below and request a demo for your use case.
        </p>

        <div class="hero__actions">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">
            Call / WhatsApp Now
          </a>
          <a class="btn btn--secondary" href="#product-enquiry">Request a Demo</a>
        </div>

        <ul class="hero__trust">
          <li>Practical workflow-first design</li>
          <li>SMB-ready customization options</li>
          <li>Phased implementation approach</li>
        </ul>
      </div>

      <div class="hero__visual">
        <img src="assets/img/Domain_Focused_Products.webp" alt="Placeholder image for Tawa Technology products and business software solutions" />
      </div>
    </div>
  </section>

  <!-- Quick CTA Strip -->
  <section class="section section--alt section--compact">
    <div class="container">
      <div class="cta-banner">
        <div class="cta-banner__content">
          <p class="eyebrow">Fastest Way to Start</p>
          <h2>Want a Quick Demo or Product Discussion?</h2>
          <p>
            Share your requirement on WhatsApp. We’ll respond with the right product/module direction and the next steps.
          </p>
        </div>
        <div class="cta-banner__actions">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">WhatsApp Now</a>
          <a class="btn btn--secondary" href="tel:+918799996171">Call +91 8799996171</a>
        </div>
      </div>
    </div>
  </section>

  <!-- Product Overview Cards -->
  <section class="section" id="product-overview">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Product Portfolio</p>
        <h2>Explore Our Product Categories</h2>
        <p>
          These products are designed around real operational workflows. You can adopt as-is or customize modules based on your requirement.
        </p>
      </div>

      <div class="product-grid">
        <article class="product-card">
          <img src="assets/img/advocate_diary_legal_domain.webp" alt="Placeholder screenshot for Advocate Diary product" />
          <div class="product-card__body">
            <span class="pill">Legal Domain</span>
            <h3>Advocate Diary</h3>
            <p>
              A legal-office oriented system concept for managing records, tasks, and day-to-day coordination.
            </p>
            <div class="card-actions">
              <a class="btn btn--secondary btn--sm" href="#advocate-diary">View Details</a>
              <a class="text-link" href="#product-enquiry">Request Demo</a>
            </div>
          </div>
        </article>

        <article class="product-card">
          <img src="assets/img/MicroFinanceSocietyManagement_finance.webp" alt="Placeholder screenshot for Micro Finance / Society Management product" />
          <div class="product-card__body">
            <span class="pill">Finance / Society</span>
            <h3>Micro Finance / Society Management</h3>
            <p>
              Structured solution approach for member management, transactions, schemes, and reporting.
            </p>
            <div class="card-actions">
              <a class="btn btn--secondary btn--sm" href="#micro-finance">View Details</a>
              <a class="text-link" href="#product-enquiry">Request Demo</a>
            </div>
          </div>
        </article>

        <article class="product-card">
          <img src="assets/img/CustomBusinessApplication.webp" alt="Placeholder screenshot for Custom Business Apps" />
          <div class="product-card__body">
            <span class="pill">Custom Build</span>
            <h3>Custom Business Apps</h3>
            <p>
              If your workflow is unique, we build custom modules and apps designed around your process.
            </p>
            <div class="card-actions">
              <a class="btn btn--secondary btn--sm" href="#custom-apps">View Details</a>
              <a class="text-link" href="#product-enquiry">Discuss Requirement</a>
            </div>
          </div>
        </article>
      </div>
    </div>
  </section>

  <!-- Product Detail: Advocate Diary -->
  <section class="section section--alt" id="advocate-diary">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Product Detail</p>
        <h2>Advocate Diary</h2>
        <p>
          Designed for advocate offices and legal professionals to maintain structured case-related records, reminders, and operational tracking.
          Replace content/screenshots later with your actual product features and modules.
        </p>
      </div>

      <div class="detail-grid">
        <div class="detail-card">
          <h3>Who It’s For</h3>
          <ul class="list-check">
            <li>Advocate offices and legal assistants</li>
            <li>Small to mid-size legal practices</li>
            <li>Teams needing structured record keeping</li>
          </ul>

          <h3>Main Value</h3>
          <ul class="list-check">
            <li>Better organization and tracking</li>
            <li>Reduced manual dependency</li>
            <li>Improved operational clarity</li>
          </ul>
        </div>

        <div class="detail-card">
          <h3>Core Modules (Placeholder)</h3>
          <ul class="list-check">
            <li>Client / party records</li>
            <li>Case details and status tracking</li>
            <li>Dates / reminders / task list</li>
            <li>Document storage structure (placeholder)</li>
            <li>Search and reporting (placeholder)</li>
          </ul>

          <div class="card-actions">
            <a class="btn btn--primary btn--sm" href="#product-enquiry">Request Demo</a>
            <a class="btn btn--secondary btn--sm" href="https://advocatediary.tawatechnology.com/login.php" target="_blank" rel="noopener noreferrer">Open Login</a>
          </div>
        </div>

        <div class="detail-media">
          <img src="assets/img/advocate_diary_legal_domain.png" alt="Advocate Diary" />
          <p class="muted">
            Advocate Diary
          </p>
        </div>
      </div>
    </div>
  </section>

  <!-- Product Detail: Micro Finance / Society -->
  <section class="section" id="micro-finance">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Product Detail</p>
        <h2>Micro Finance / Society Management</h2>
        <p>
          Built for societies and micro-finance operations that need structured member management, transaction tracking, schemes, and reporting.
          Customize modules based on your operating model.
        </p>
      </div>

      <div class="detail-grid">
        <div class="detail-card">
          <h3>Who It’s For</h3>
          <ul class="list-check">
            <li>Micro finance societies / organizations</li>
            <li>Member-based institutions</li>
            <li>Branch-based operations</li>
          </ul>

          <h3>Main Value</h3>
          <ul class="list-check">
            <li>Structured transaction records</li>
            <li>Better reporting visibility</li>
            <li>Improved workflow control</li>
          </ul>
        </div>

        <div class="detail-card">
          <h3>Core Modules</h3>
          <ul class="list-check">
            <li>Member onboarding + KYC record structure</li>
            <li>Deposit schemes (FD/RD/Daily/Weekly/Monthly)</li>
            <li>Loan modules (personal/business/gold etc.)</li>
            <li>Cashbook / bankbook support</li>
            <li>Reports & dashboards</li>
          </ul>

          <div class="card-actions">
            <a class="btn btn--primary btn--sm" href="#product-enquiry">Request Demo</a>
            <a class="btn btn--secondary btn--sm" href="contact.php">Discuss Requirement</a>
          </div>
        </div>

        <div class="detail-media">
          <img src="assets/img/MicroFinanceSocietyManagement_finance.webp" alt=" Micro Finance / Society Management" />
          <p class="muted">
            Micro Finance / Society Management
          </p>
        </div>
      </div>
    </div>
  </section>

  <!-- Product Detail: Custom Apps -->
  <section class="section section--alt" id="custom-apps">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Custom Product Build</p>
        <h2>Custom Business Apps & Domain Modules</h2>
        <p>
          If your workflow doesn’t match an existing product, we build a custom solution based on your exact process.
          This is ideal for SMBs that want digitization without unnecessary complexity.
        </p>
      </div>

      <div class="card-grid card-grid--3">
        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">🧩</div>
          <h3>Workflow-Based Modules</h3>
          <p>We design modules around your real operational flow: input → process → output.</p>
          <ul class="list-check">
            <li>Role-based access (admin/staff)</li>
            <li>Record + tracking + reporting structure</li>
            <li>Phase-wise implementation</li>
          </ul>
        </article>

        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">📄</div>
          <h3>Digitization Starter Pack</h3>
          <p>Start small: organize data, create templates, and digitize step-by-step.</p>
          <ul class="list-check">
            <li>Requirement discovery</li>
            <li>Process mapping</li>
            <li>Simple system build</li>
          </ul>
        </article>

        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">🚀</div>
          <h3>MVP / First Version Build</h3>
          <p>Build a minimum viable product and evolve based on usage and feedback.</p>
          <ul class="list-check">
            <li>Prioritized scope</li>
            <li>Milestone delivery</li>
            <li>Enhancement roadmap</li>
          </ul>
        </article>
      </div>

      <div class="cta-inline">
        <a class="btn btn--secondary" href="software.php">Explore Software Services</a>
        <a class="btn btn--primary" href="#product-enquiry">Discuss Custom Requirement</a>
      </div>
    </div>
  </section>

  <!-- Why Choose -->
  <section class="section" id="why-products">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Why Our Products</p>
        <h2>Built for Practical Use + Customization</h2>
        <p>
          Products are not “one-size-fits-all”. Our approach allows adoption + customization based on the organization’s real workflow.
        </p>
      </div>

      <div class="card-grid card-grid--3">
        <article class="feature-card">
          <h3>Workflow-First Design</h3>
          <p>We focus on how your team actually works, then structure the system around it.</p>
        </article>
        <article class="feature-card">
          <h3>SMB-Friendly Implementation</h3>
          <p>Practical setup and phased rollout rather than complex enterprise overhead.</p>
        </article>
        <article class="feature-card">
          <h3>Support + Improvements</h3>
          <p>We can evolve modules as your processes grow or requirements change.</p>
        </article>
        <article class="feature-card">
          <h3>Better Reporting Readiness</h3>
          <p>Structured data and reporting-friendly design improve visibility over time.</p>
        </article>
        <article class="feature-card">
          <h3>Fast Start</h3>
          <p>Start with essential modules first, then expand in phases.</p>
        </article>
        <article class="feature-card">
          <h3>Software + Training Expertise</h3>
          <p>Our training and software experience improves practical implementation thinking.</p>
        </article>
      </div>
    </div>
  </section>

  <!-- FAQ -->
  <section class="section section--alt" id="products-faq">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Products FAQ</p>
        <h2>Frequently Asked Questions</h2>
        <p>These are common questions organizations ask before requesting a demo.</p>
      </div>

      <div class="faq-list">
        <details>
          <summary>Can these products be customized?</summary>
          <p>
            Yes. We can customize modules, workflows, forms, and reports based on your operational requirement.
          </p>
        </details>

        <details>
          <summary>Do you provide demo and onboarding support?</summary>
          <p>
            Yes. We can schedule a demo and guide your team on the usage and best implementation approach.
          </p>
        </details>

        <details>
          <summary>Can you build a custom product if my workflow is different?</summary>
          <p>
            Yes. If an existing product does not match your requirement, we can design and build a custom application or a module-based system.
          </p>
        </details>

        <details>
          <summary>How do we start the discussion?</summary>
          <p>
            The fastest way is WhatsApp or a quick call. You can also submit the enquiry form on this page and we will follow up.
          </p>
        </details>
      </div>
    </div>
  </section>

  <!-- Product Enquiry / Demo Form -->
  <section class="section contact-section" id="product-enquiry">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Request Demo / Enquiry</p>
        <h2>Want a Demo or Product Fit Discussion?</h2>
        <p>
          Share your requirement and we’ll suggest the right product/module approach — plus the next step for demo and implementation.
        </p>
      </div>

      <div class="contact-grid">
        <div class="contact-card">
          <h3>Quick Contact Options</h3>
          <ul class="contact-list">
            <li><strong>Phone:</strong> <a href="tel:+918799996171">+91 8799996171</a></li>
            <li><strong>WhatsApp:</strong> <a href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">Start WhatsApp Chat</a></li>
            <li><strong>Email:</strong> <a href="mailto:info@tawatechnology.com">info@tawatechnology.com</a></li>
            <li><strong>Location:</strong> Nagpur, India (Placeholder address)</li>
            <li><strong>Fastest Start:</strong> Share your use case + organization type on WhatsApp</li>
          </ul>

          <div class="contact-actions">
            <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">Call / WhatsApp Now</a>
            <a class="btn btn--secondary" href="contact.php">Talk to an Expert</a>
          </div>
        </div>

        <form class="contact-form" action="#" method="post" novalidate>
          <h3>Request a Demo / Product Enquiry</h3>

          <div class="form-row">
            <label for="orgName">Organization Name *</label>
            <input type="text" id="orgName" name="orgName" placeholder="Enter organization name" required />
          </div>

          <div class="form-row form-row--2">
            <div>
              <label for="contactName">Contact Person *</label>
              <input type="text" id="contactName" name="contactName" placeholder="Your name" required />
            </div>
            <div>
              <label for="phone">Phone / WhatsApp *</label>
              <input type="tel" id="phone" name="phone" placeholder="+91 XXXXX XXXXX" required />
            </div>
          </div>

          <div class="form-row form-row--2">
            <div>
              <label for="email">Email *</label>
              <input type="email" id="email" name="email" placeholder="you@organization.com" required />
            </div>
            <div>
              <label for="productInterest">Product Interested In *</label>
              <select id="productInterest" name="productInterest" required>
                <option value="">Select product</option>
                <option value="advocate-diary">Advocate Diary</option>
                <option value="micro-finance">Micro Finance / Society Management</option>
                <option value="custom-apps">Custom Business App</option>
                <option value="not-sure">Not Sure Yet</option>
              </select>
            </div>
          </div>

          <div class="form-row">
            <label for="useCase">Use Case / Requirement Details *</label>
            <textarea id="useCase" name="useCase" rows="6" placeholder="Describe your process and what you want to digitize..." required></textarea>
          </div>

          <div class="form-row checkbox-row">
            <input type="checkbox" id="consent" name="consent" required />
            <label for="consent">I agree to be contacted by Tawa Technology regarding this product enquiry.</label>
          </div>

          <button type="submit" class="btn btn--primary">Send Demo Request</button>
          <p class="form-note">
            Placeholder form setup. Connect later to Formspree, Netlify Forms, or PHP mailer on your hosting.
          </p>
        </form>
      </div>
    </div>
  </section>
</main>

  <!-- Footer -->
  <footer class="site-footer">
    <div class="container footer__grid">
      <div class="footer__col footer__col--brand">
        <a href="index.php" class="brand brand--footer">
          <img src="assets/img/logo.webp" alt="Tawa Technology logo" class="brand__logo" />
          <div class="brand__text">
            <span class="brand__name">Tawa Technology</span>
            <span class="brand__tagline">Empowering Businesses &amp; Students</span>
          </div>
        </a>

        <p class="footer__about">
          Tawa Technology helps businesses digitize operations through practical software solutions and helps students build job-ready skills through project-based IT training.
        </p>

        <div class="footer__quick-contact">
          <a href="tel:+918799996171">📞 +91 8799996171</a>
          <a href="mailto:info@tawatechnology.com">✉️ info@tawatechnology.com</a>
          <a href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">💬 WhatsApp Chat</a>
          <span>📍 Nagpur, India</span>
        </div>
      </div>

      <div class="footer__col">
        <h3>Software Solutions</h3>
        <ul>
          <li><a href="/software.php">Custom Web Applications</a></li>
          <li><a href="/software.php">Java / Enterprise Solutions</a></li>
          <li><a href="/software.php">Business Websites</a></li>
          <li><a href="/software.php">Process Digitization</a></li>
          <li><a href="/software.php">SEO & Digital Consulting</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Products</h3>
        <ul>
          <li><a href="products.php#advocate-diary">Advocate Diary</a></li>
          <li><a href="products.php#micro-finance">Micro Finance Management</a></li>
          <li><a href="products.php#custom-apps">Custom Business Apps</a></li>
          <li><a href="products.php">Product Demo Request</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Training & Courses</h3>
        <ul>
          <li><a href="training.php#java-full-stack">Java Full Stack</a></li>
          <li><a href="training.php#core-java">Core Java</a></li>
          <li><a href="training.php#sql-powerbi">SQL / Power BI</a></li>
          <li><a href="training.php#web-development">Web Development</a></li>
          <li><a href="training.php#fees">Course Fees</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Company</h3>
        <ul>
          <li><a href="about.php">About Tawa Technology</a></li>
          <li><a href="case-studies.php">Case Studies</a></li>
          <li><a href="blog.php">Resources / Blog</a></li>
          <li><a href="faq.php">FAQ</a></li>
          <li><a href="contact.php">Contact / Enquiry</a></li>
        </ul>
      </div>
    </div>

    <div class="container footer__bottom">
      <p>© <span id="year"></span> Tawa Technology. All rights reserved.</p>
      <div class="footer__links">
        <a href="privacy-policy.php">Privacy Policy</a>
        <a href="terms.php">Terms</a>
        <a href="contact.php">Contact</a>
      </div>
    </div>
  </footer>

  <!-- Mobile Sticky CTA Bar -->
  <div class="mobile-cta" role="region" aria-label="Quick contact actions">
    <a class="mobile-cta__btn" href="tel:+918799996171" aria-label="Call Tawa Technology">
      📞 Call
    </a>
    <a class="mobile-cta__btn mobile-cta__btn--whatsapp"
      href="https://wa.me/918799996171"
      target="_blank" rel="noopener noreferrer"
      aria-label="WhatsApp Tawa Technology">
      WhatsApp
    </a>
  </div>
  <script src="assets/js/main.js"></script>
  </body>

  </html>