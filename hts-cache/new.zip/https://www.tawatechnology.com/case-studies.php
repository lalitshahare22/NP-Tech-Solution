<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Case Studies | Tawa Technology | Software Projects &amp; Business Outcomes</title>
  <meta name="description" content="Explore selected case studies and project examples from Tawa Technology—software development, process digitization, and digital solutions for businesses." />
  <meta name="theme-color" content="#003399" />

  <!-- Open Graph (basic, reusable) -->
  <meta property="og:title" content="Case Studies | Tawa Technology | Software Projects &amp; Business Outcomes" />
  <meta property="og:description" content="Explore selected case studies and project examples from Tawa Technology—software development, process digitization, and digital solutions for businesses." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://www.tawatechnology.com/" />
  <meta property="og:image" content="assets/img/hero-placeholder.jpg" />

  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Poppins:wght@600;700;800&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="assets/css/style.css" />
</head>
<body>
  <a class="skip-link" href="#main-content">Skip to content</a>

  <!-- Top Utility Bar -->
  <div class="topbar topbar--enhanced">
    <div class="container topbar__inner">
      <div class="topbar__left">
        <span class="topbar__item">📍 Nagpur, India</span>
        <a class="topbar__item" href="tel:+918799996171">📞 +91 8799996171</a>
        <a class="topbar__item" href="mailto:info@tawatechnology.com">✉️ info@tawatechnology.com</a>
      </div>
      <div class="topbar__right">
        <a class="topbar__pill" href="contact.php">Enquiry Form</a>
        <a class="topbar__pill topbar__pill--whatsapp" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">WhatsApp</a>
      </div>
    </div>
  </div>

  <!-- Main Header -->
  <header class="site-header" id="site-header">
    <div class="container header__inner">
      <a href="index.php" class="brand" aria-label="Tawa Technology home">
        <img src="assets/img/logo.webp" alt="Tawa Technology logo" class="brand__logo" />
        <div class="brand__text">
          <span class="brand__name">Tawa Technology</span>
          <span class="brand__tagline">Empowering Businesses &amp; Students</span>
        </div>
      </a>

      <button
        class="nav-toggle"
        id="navToggle"
        aria-expanded="false"
        aria-controls="primaryNav"
        aria-label="Open navigation menu"
      >
        <span></span>
        <span></span>
        <span></span>
      </button>

      <nav class="primary-nav" id="primaryNav" aria-label="Primary navigation">
        <ul class="menu">
          <li><a class="" href="index.php">Home</a></li>

          <li><a class="" href="software.php">Software Solutions</a></li>

          <!-- Dropdown-ready item -->
          <li class="has-dropdown">
            <button class="menu-btn " type="button" aria-expanded="false">
              Products
              <span class="caret" aria-hidden="true">▾</span>
            </button>
            <div class="dropdown" role="menu" aria-label="Products submenu">
              <a href="products.php">All Products</a>
              <a href="products.php#advocate-diary">Advocate Diary</a>
              <a href="products.php#micro-finance">Micro Finance</a>
              <a href="products.php#custom-apps">Custom Business Apps</a>
            </div>
          </li>

          <li class="has-dropdown">
            <button class="menu-btn " type="button" aria-expanded="false">
              Training
              <span class="caret" aria-hidden="true">▾</span>
            </button>
            <div class="dropdown" role="menu" aria-label="Training submenu">
              <a href="training.php">All Courses</a>
              <a href="training.php#java-full-stack">Java Full Stack</a>
              <a href="training.php#core-java">Core Java</a>
              <a href="training.php#sql-powerbi">SQL / Power BI</a>
              <a href="training.php#web-development">Web Development</a>
            </div>
          </li>

          <li><a class="is-active" href="case-studies.php">Case Studies</a></li>
          <li><a class="" href="about.php">About</a></li>
          <li><a class="" href="blog.php">Resources</a></li>
          <li><a class="" href="contact.php">Contact</a></li>
        </ul>

        <div class="nav-cta nav-cta--desktop">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">
            Call / WhatsApp Now
          </a>
        </div>
      </nav>
    </div>
  </header>
<main id="main-content">
  <!-- Hero -->
  <section class="section hero hero--inner">
    <div class="container hero__grid">
      <div class="hero__content">
        <p class="eyebrow">Case Studies & Project Examples</p>
        <h1>Proof Through Outcomes: Practical Projects Built for Real Workflows</h1>
        <p class="hero__lead">
          Below are structured case studies showing how we approach real problems:
          understand the process → define scope → implement a solution → deliver measurable operational improvements.
        </p>

        <div class="hero__actions">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">
            Call / WhatsApp Now
          </a>
          <a class="btn btn--secondary" href="#case-enquiry">Discuss Similar Requirement</a>
        </div>

        <ul class="hero__trust">
          <li>Requirement-first approach</li>
          <li>Workflow-focused implementation</li>
          <li>Clear scope + phased delivery</li>
        </ul>
      </div>

      <div class="hero__visual">
        <img src="assets/img/PrrofThroughOutcomes.webp" alt="Placeholder image for business software projects and implementation outcomes" />
      </div>
    </div>
  </section>

  <!-- Quick CTA Strip -->
  <section class="section section--alt section--compact">
    <div class="container">
      <div class="cta-banner">
        <div class="cta-banner__content">
          <p class="eyebrow">Need Something Similar?</p>
          <h2>Share Your Requirement — We’ll Suggest a Practical Solution Path</h2>
          <p>
            The fastest way is WhatsApp. Share your current problem and what you want to improve.
          </p>
        </div>
        <div class="cta-banner__actions">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">WhatsApp Now</a>
          <a class="btn btn--secondary" href="/software.php">Explore Services</a>
        </div>
      </div>
    </div>
  </section>

  <!-- Filters / Categories (UI-only, placeholder) -->
  <section class="section" id="case-filters">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Browse By Category</p>
        <h2>Case Study Categories (Placeholder)</h2>
        <p>
          These filters are optional. You can remove them if you want a simpler page.
        </p>
      </div>

      <div class="chip-row" role="list" aria-label="Case study categories">
        <a class="chip" href="#case-list">All</a>
        <a class="chip" href="#software-projects">Custom Software</a>
        <a class="chip" href="#websites">Websites</a>
        <a class="chip" href="#digitization">Process Digitization</a>
        <a class="chip" href="#domain-products">Domain Solutions</a>
      </div>
    </div>
  </section>

  <!-- Case Studies Grid -->
  <section class="section section--alt" id="case-list">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Selected Case Studies</p>
        <h2>Project Examples</h2>
        <p>
          <strong>Problem → Solution → Outcome</strong>
        </p>
      </div>

      <div class="case-study-grid">
        <!-- Case 1 -->
        <article class="case-study-card" id="software-projects">
          <div class="case-study-card__media">
            <img src="assets/img/Custom_Software.webp" alt="case study: custom workflow application" />
          </div>
          <div class="case-study-card__body">
            <div class="case-study-card__top">
              <span class="pill">Custom Software</span>
              <h3>Custom Workflow Application for Operations Tracking</h3>
              <p class="muted">Industry: Retail • Location: Hingna, Nagpur, India</p>
            </div>

            <div class="case-study-card__content">
              <h4>Problem</h4>
              <p>
                The business depended on manual tracking (notebooks / spreadsheets). Records were inconsistent and reporting visibility was limited.
              </p>

              <h4>Solution</h4>
              <ul class="list-check">
                <li>Requirement-driven modules for data entry, tracking, and search</li>
                <li>Role-based access (admin/staff) </li>
                <li>Structured report-ready data format</li>
              </ul>

              <h4>Outcome</h4>
              <ul class="list-check">
                <li>Improved process clarity and record structure</li>
                <li>Reduced manual duplication</li>
                <li>Better reporting readiness</li>
              </ul>
            </div>

            <div class="card-actions">
              <a class="btn btn--secondary btn--sm" href="#case-enquiry">Request Similar Solution</a>
              <a class="text-link" href="/software.php">View Services</a>
            </div>
          </div>
        </article>

        <!-- Case 2 -->
        <article class="case-study-card" id="websites">
          <div class="case-study-card__media">
            <img src="assets/img/ConversionFocusedBusiness.webp" alt="case study: professional business website" />
          </div>
          <div class="case-study-card__body">
            <div class="case-study-card__top">
              <span class="pill">Website + Lead Capture</span>
              <h3>Conversion-Focused Business Website for Better Enquiries</h3>
              <p class="muted">Industry: Finance, e-Commerce, Retail • Use Case: Service business website</p>
            </div>

            <div class="case-study-card__content">
              <h4>Problem</h4>
              <p>
                The business had low online credibility and unclear messaging. Visitors were not converting into enquiries.
              </p>

              <h4>Solution</h4>
              <ul class="list-check">
                <li>Modern responsive multi-page website structure</li>
                <li>Clear services + CTA flow (Call/WhatsApp/Enquiry)</li>
                <li>SEO-friendly page structure and content blocks</li>
              </ul>

              <h4>Outcome</h4>
              <ul class="list-check">
                <li>Improved clarity and trust signals</li>
                <li>Better enquiry readiness</li>
                <li>Structured content supporting local SEO</li>
              </ul>
            </div>

            <div class="card-actions">
              <a class="btn btn--secondary btn--sm" href="#case-enquiry">Build My Website</a>
              <a class="text-link" href="/software.php#software-services">Website Services</a>
            </div>
          </div>
        </article>

        <!-- Case 3 -->
        <article class="case-study-card" id="digitization">
          <div class="case-study-card__media">
            <img src="assets/img/DigitizationRoadmapPhasewiseImplementation.webp" alt="Process digitization system" />
          </div>
          <div class="case-study-card__body">
            <div class="case-study-card__top">
              <span class="pill">Process Digitization</span>
              <h3>Digitization Roadmap + Phase-wise Implementation</h3>
              <p class="muted">Industry: Service and Manufacturing • Focus: Operational digitization</p>
            </div>

            <div class="case-study-card__content">
              <h4>Problem</h4>
              <p>
                The organization wanted digitization but was unsure where to start. Existing processes were unstructured and manual.
              </p>

              <h4>Solution</h4>
              <ul class="list-check">
                <li>Process discovery + mapping (what happens now)</li>
                <li>Define essential modules first (MVP approach)</li>
                <li>Phased roadmap for improvements and expansions</li>
              </ul>

              <h4>Outcome</h4>
              <ul class="list-check">
                <li>Clear implementation plan and scope</li>
                <li>Better workflow visibility</li>
                <li>Foundation for future automation</li>
              </ul>
            </div>

            <div class="card-actions">
              <a class="btn btn--secondary btn--sm" href="#case-enquiry">Digitize My Process</a>
              <a class="text-link" href="software.php#process">How We Work</a>
            </div>
          </div>
        </article>

        <!-- Case 4 -->
        <article class="case-study-card" id="domain-products">
          <div class="case-study-card__media">
            <img src="assets/img/DomainOrientedystemSetup.webp" alt="Placeholder image for case study: domain product implementation" />
          </div>
          <div class="case-study-card__body">
            <div class="case-study-card__top">
              <span class="pill">Domain Solution</span>
              <h3>Domain-Oriented System Setup (Legal/Finance)</h3>
              <p class="muted">Product/Module: Advocate Diary / Micro Finance</p>
            </div>

            <div class="case-study-card__content">
              <h4>Problem</h4>
              <p>
                The client needed a domain-oriented solution but also required customization based on their specific team workflow.
              </p>

              <h4>Solution</h4>
              <ul class="list-check">
                <li>Adopt a base product/module structure</li>
                <li>Customize workflows, screens, and reports</li>
                <li>Support onboarding and phased rollout</li>
              </ul>

              <h4>Outcome</h4>
              <ul class="list-check">
                <li>Faster starting point compared to building from scratch</li>
                <li>Better workflow alignment after customization</li>
                <li>Improved consistency in records</li>
              </ul>
            </div>

            <div class="card-actions">
              <a class="btn btn--secondary btn--sm" href="products.php#product-enquiry">Request Demo</a>
              <a class="text-link" href="products.php">Explore Products</a>
            </div>
          </div>
        </article>
      </div>

      <div class="cta-inline">
        <a class="btn btn--secondary" href="/products.php">Explore Products</a>
        <a class="btn btn--primary" href="#case-enquiry">Discuss Your Requirement</a>
      </div>
    </div>
  </section>

  <!-- “How to write a case study” helper section -->
  <section class="section" id="case-study-template">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Make This Page Stronger</p>
        <h2>Case Study Template </h2>
      <!--  <p>
          Copy this structure when you replace placeholders with real work. Even 3–6 strong case studies can significantly improve credibility.
        </p>
          -->
      </div>

      <div class="card-grid card-grid--3">
        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">🎯</div>
          <h3>1) Problem</h3>
          <p>What was broken or inefficient?</p>
          <ul class="list-check">
            <li>Manual work, delays, errors</li>
            <li>Reporting gaps</li>
            <li>Low online credibility</li>
          </ul>
        </article>

        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">🧩</div>
          <h3>2) Solution</h3>
          <p>What we built and why it fits the workflow.</p>
          <ul class="list-check">
            <li>Modules / screens / flow</li>
            <li>Tech/approach (simple)</li>
            <li>Phased delivery plan</li>
          </ul>
        </article>

        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">📈</div>
          <h3>3) Outcome</h3>
          <p>What improved after implementation?</p>
          <ul class="list-check">
            <li>Time saved (estimate if needed)</li>
            <li>Better visibility</li>
            <li>Reduced errors</li>
          </ul>
        </article>
      </div>
    </div>
  </section>

  <!-- Enquiry -->
  <section class="section contact-section section--alt" id="case-enquiry">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Discuss a Similar Project</p>
        <h2>Want a Similar Solution for Your Business?</h2>
        <p>
          Share your problem and what you want to improve. We’ll guide you toward a practical solution path.
        </p>
      </div>

      <div class="contact-grid">
        <div class="contact-card">
          <h3>Quick Contact Options</h3>
          <ul class="contact-list">
            <li><strong>Phone:</strong> <a href="tel:+918799996171">+91 8799996171</a></li>
            <li><strong>WhatsApp:</strong> <a href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">Start WhatsApp Chat</a></li>
            <li><strong>Email:</strong> <a href="mailto:info@tawatechnology.com">info@tawatechnology.com</a></li>
            <li><strong>Location:</strong> Nagpur, India (Placeholder address)</li>
          </ul>

          <div class="contact-actions">
            <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">Call / WhatsApp Now</a>
            <a class="btn btn--secondary" href="/contact.php">Talk to an Expert</a>
          </div>
        </div>

        <form class="contact-form" action="#" method="post" novalidate>
          <h3>Request Similar Solution</h3>

          <div class="form-row">
            <label for="orgName">Business / Organization *</label>
            <input type="text" id="orgName" name="orgName" placeholder="Enter your business name" required />
          </div>

          <div class="form-row form-row--2">
            <div>
              <label for="contactName">Your Name *</label>
              <input type="text" id="contactName" name="contactName" placeholder="Full name" required />
            </div>
            <div>
              <label for="phone">Phone / WhatsApp *</label>
              <input type="tel" id="phone" name="phone" placeholder="+91 XXXXX XXXXX" required />
            </div>
          </div>

          <div class="form-row form-row--2">
            <div>
              <label for="email">Email *</label>
              <input type="email" id="email" name="email" placeholder="you@company.com" required />
            </div>
            <div>
              <label for="projectType">Project Type *</label>
              <select id="projectType" name="projectType" required>
                <option value="">Select type</option>
                <option value="custom-software">Custom Software / Web App</option>
                <option value="website">Website / Redesign</option>
                <option value="digitization">Process Digitization</option>
                <option value="domain-solution">Domain Solution / Product</option>
                <option value="not-sure">Not Sure Yet</option>
              </select>
            </div>
          </div>

          <div class="form-row">
            <label for="message">Describe Your Problem / Requirement *</label>
            <textarea id="message" name="message" rows="6" placeholder="What is your current process? What is the problem and what outcome do you want?" required></textarea>
          </div>

          <div class="form-row checkbox-row">
            <input type="checkbox" id="consent" name="consent" required />
            <label for="consent">I agree to be contacted by Tawa Technology regarding this enquiry.</label>
          </div>

          <button type="submit" class="btn btn--primary">Send Enquiry</button>
          <p class="form-note">
            
          </p>
        </form>
      </div>
    </div>
  </section>
</main>

  <!-- Footer -->
  <footer class="site-footer">
    <div class="container footer__grid">
      <div class="footer__col footer__col--brand">
        <a href="index.php" class="brand brand--footer">
          <img src="assets/img/logo.webp" alt="Tawa Technology logo" class="brand__logo" />
          <div class="brand__text">
            <span class="brand__name">Tawa Technology</span>
            <span class="brand__tagline">Empowering Businesses &amp; Students</span>
          </div>
        </a>

        <p class="footer__about">
          Tawa Technology helps businesses digitize operations through practical software solutions and helps students build job-ready skills through project-based IT training.
        </p>

        <div class="footer__quick-contact">
          <a href="tel:+918799996171">📞 +91 8799996171</a>
          <a href="mailto:info@tawatechnology.com">✉️ info@tawatechnology.com</a>
          <a href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">💬 WhatsApp Chat</a>
          <span>📍 Nagpur, India</span>
        </div>
      </div>

      <div class="footer__col">
        <h3>Software Solutions</h3>
        <ul>
          <li><a href="/software.php">Custom Web Applications</a></li>
          <li><a href="/software.php">Java / Enterprise Solutions</a></li>
          <li><a href="/software.php">Business Websites</a></li>
          <li><a href="/software.php">Process Digitization</a></li>
          <li><a href="/software.php">SEO & Digital Consulting</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Products</h3>
        <ul>
          <li><a href="products.php#advocate-diary">Advocate Diary</a></li>
          <li><a href="products.php#micro-finance">Micro Finance Management</a></li>
          <li><a href="products.php#custom-apps">Custom Business Apps</a></li>
          <li><a href="products.php">Product Demo Request</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Training & Courses</h3>
        <ul>
          <li><a href="training.php#java-full-stack">Java Full Stack</a></li>
          <li><a href="training.php#core-java">Core Java</a></li>
          <li><a href="training.php#sql-powerbi">SQL / Power BI</a></li>
          <li><a href="training.php#web-development">Web Development</a></li>
          <li><a href="training.php#fees">Course Fees</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Company</h3>
        <ul>
          <li><a href="about.php">About Tawa Technology</a></li>
          <li><a href="case-studies.php">Case Studies</a></li>
          <li><a href="blog.php">Resources / Blog</a></li>
          <li><a href="faq.php">FAQ</a></li>
          <li><a href="contact.php">Contact / Enquiry</a></li>
        </ul>
      </div>
    </div>

    <div class="container footer__bottom">
      <p>© <span id="year"></span> Tawa Technology. All rights reserved.</p>
      <div class="footer__links">
        <a href="privacy-policy.php">Privacy Policy</a>
        <a href="terms.php">Terms</a>
        <a href="contact.php">Contact</a>
      </div>
    </div>
  </footer>

  <!-- Mobile Sticky CTA Bar -->
  <div class="mobile-cta" role="region" aria-label="Quick contact actions">
    <a class="mobile-cta__btn" href="tel:+918799996171" aria-label="Call Tawa Technology">
      📞 Call
    </a>
    <a class="mobile-cta__btn mobile-cta__btn--whatsapp"
      href="https://wa.me/918799996171"
      target="_blank" rel="noopener noreferrer"
      aria-label="WhatsApp Tawa Technology">
      WhatsApp
    </a>
  </div>
  <script src="assets/js/main.js"></script>
  </body>

  </html>