<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Software Solutions | Tawa Technology</title>
  <meta name="description" content="Custom web applications, Java solutions, business websites, and digital consulting for small and medium businesses." />
  <meta name="theme-color" content="#003399" />

  <!-- Open Graph (basic, reusable) -->
  <meta property="og:title" content="Software Solutions | Tawa Technology" />
  <meta property="og:description" content="Custom web applications, Java solutions, business websites, and digital consulting for small and medium businesses." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://www.tawatechnology.com/" />
  <meta property="og:image" content="assets/img/hero-placeholder.jpg" />

  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Poppins:wght@600;700;800&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="assets/css/style.css" />
</head>
<body>
  <a class="skip-link" href="#main-content">Skip to content</a>

  <!-- Top Utility Bar -->
  <div class="topbar topbar--enhanced">
    <div class="container topbar__inner">
      <div class="topbar__left">
        <span class="topbar__item">📍 Nagpur, India</span>
        <a class="topbar__item" href="tel:+918799996171">📞 +91 8799996171</a>
        <a class="topbar__item" href="mailto:info@tawatechnology.com">✉️ info@tawatechnology.com</a>
      </div>
      <div class="topbar__right">
        <a class="topbar__pill" href="contact.php">Enquiry Form</a>
        <a class="topbar__pill topbar__pill--whatsapp" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">WhatsApp</a>
      </div>
    </div>
  </div>

  <!-- Main Header -->
  <header class="site-header" id="site-header">
    <div class="container header__inner">
      <a href="index.php" class="brand" aria-label="Tawa Technology home">
        <img src="assets/img/logo.webp" alt="Tawa Technology logo" class="brand__logo" />
        <div class="brand__text">
          <span class="brand__name">Tawa Technology</span>
          <span class="brand__tagline">Empowering Businesses &amp; Students</span>
        </div>
      </a>

      <button
        class="nav-toggle"
        id="navToggle"
        aria-expanded="false"
        aria-controls="primaryNav"
        aria-label="Open navigation menu"
      >
        <span></span>
        <span></span>
        <span></span>
      </button>

      <nav class="primary-nav" id="primaryNav" aria-label="Primary navigation">
        <ul class="menu">
          <li><a class="" href="index.php">Home</a></li>

          <li><a class="is-active" href="software.php">Software Solutions</a></li>

          <!-- Dropdown-ready item -->
          <li class="has-dropdown">
            <button class="menu-btn " type="button" aria-expanded="false">
              Products
              <span class="caret" aria-hidden="true">▾</span>
            </button>
            <div class="dropdown" role="menu" aria-label="Products submenu">
              <a href="products.php">All Products</a>
              <a href="products.php#advocate-diary">Advocate Diary</a>
              <a href="products.php#micro-finance">Micro Finance</a>
              <a href="products.php#custom-apps">Custom Business Apps</a>
            </div>
          </li>

          <li class="has-dropdown">
            <button class="menu-btn " type="button" aria-expanded="false">
              Training
              <span class="caret" aria-hidden="true">▾</span>
            </button>
            <div class="dropdown" role="menu" aria-label="Training submenu">
              <a href="training.php">All Courses</a>
              <a href="training.php#java-full-stack">Java Full Stack</a>
              <a href="training.php#core-java">Core Java</a>
              <a href="training.php#sql-powerbi">SQL / Power BI</a>
              <a href="training.php#web-development">Web Development</a>
            </div>
          </li>

          <li><a class="" href="case-studies.php">Case Studies</a></li>
          <li><a class="" href="about.php">About</a></li>
          <li><a class="" href="blog.php">Resources</a></li>
          <li><a class="" href="contact.php">Contact</a></li>
        </ul>

        <div class="nav-cta nav-cta--desktop">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">
            Call / WhatsApp Now
          </a>
        </div>
      </nav>
    </div>
  </header>
<main id="main-content">
  <section class="section">
    <div class="container">
      <h1>Software Solutions</h1>
      <p>Software page content goes here.</p>
    </div>
  </section>
</main>

  <!-- Footer -->
  <footer class="site-footer">
    <div class="container footer__grid">
      <div class="footer__col footer__col--brand">
        <a href="index.php" class="brand brand--footer">
          <img src="assets/img/logo.webp" alt="Tawa Technology logo" class="brand__logo" />
          <div class="brand__text">
            <span class="brand__name">Tawa Technology</span>
            <span class="brand__tagline">Empowering Businesses &amp; Students</span>
          </div>
        </a>

        <p class="footer__about">
          Tawa Technology helps businesses digitize operations through practical software solutions and helps students build job-ready skills through project-based IT training.
        </p>

        <div class="footer__quick-contact">
          <a href="tel:+918799996171">📞 +91 8799996171</a>
          <a href="mailto:info@tawatechnology.com">✉️ info@tawatechnology.com</a>
          <a href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">💬 WhatsApp Chat</a>
          <span>📍 Nagpur, India</span>
        </div>
      </div>

      <div class="footer__col">
        <h3>Software Solutions</h3>
        <ul>
          <li><a href="/software.php">Custom Web Applications</a></li>
          <li><a href="/software.php">Java / Enterprise Solutions</a></li>
          <li><a href="/software.php">Business Websites</a></li>
          <li><a href="/software.php">Process Digitization</a></li>
          <li><a href="/software.php">SEO & Digital Consulting</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Products</h3>
        <ul>
          <li><a href="products.php#advocate-diary">Advocate Diary</a></li>
          <li><a href="products.php#micro-finance">Micro Finance Management</a></li>
          <li><a href="products.php#custom-apps">Custom Business Apps</a></li>
          <li><a href="products.php">Product Demo Request</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Training & Courses</h3>
        <ul>
          <li><a href="training.php#java-full-stack">Java Full Stack</a></li>
          <li><a href="training.php#core-java">Core Java</a></li>
          <li><a href="training.php#sql-powerbi">SQL / Power BI</a></li>
          <li><a href="training.php#web-development">Web Development</a></li>
          <li><a href="training.php#fees">Course Fees</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Company</h3>
        <ul>
          <li><a href="about.php">About Tawa Technology</a></li>
          <li><a href="case-studies.php">Case Studies</a></li>
          <li><a href="blog.php">Resources / Blog</a></li>
          <li><a href="faq.php">FAQ</a></li>
          <li><a href="contact.php">Contact / Enquiry</a></li>
        </ul>
      </div>
    </div>

    <div class="container footer__bottom">
      <p>© <span id="year"></span> Tawa Technology. All rights reserved.</p>
      <div class="footer__links">
        <a href="privacy-policy.php">Privacy Policy</a>
        <a href="terms.php">Terms</a>
        <a href="contact.php">Contact</a>
      </div>
    </div>
  </footer>

  <!-- Mobile Sticky CTA Bar -->
  <div class="mobile-cta" role="region" aria-label="Quick contact actions">
    <a class="mobile-cta__btn" href="tel:+918799996171" aria-label="Call Tawa Technology">
      📞 Call
    </a>
    <a class="mobile-cta__btn mobile-cta__btn--whatsapp"
      href="https://wa.me/918799996171"
      target="_blank" rel="noopener noreferrer"
      aria-label="WhatsApp Tawa Technology">
      WhatsApp
    </a>
  </div>
  <script src="assets/js/main.js"></script>
  </body>

  </html>