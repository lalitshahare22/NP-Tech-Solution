<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Training &amp; Courses | Tawa Technology | Java Full Stack, Core Java, SQL, Power BI, Web Development</title>
  <meta name="description" content="Tawa Technology offers real-time, project-based IT training in Java Full Stack, Core Java, SQL, Power BI, and Web Development for students and professionals in Nagpur." />
  <meta name="theme-color" content="#003399" />

  <!-- Open Graph (basic, reusable) -->
  <meta property="og:title" content="Training &amp; Courses | Tawa Technology | Java Full Stack, Core Java, SQL, Power BI, Web Development" />
  <meta property="og:description" content="Tawa Technology offers real-time, project-based IT training in Java Full Stack, Core Java, SQL, Power BI, and Web Development for students and professionals in Nagpur." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://www.tawatechnology.com/" />
  <meta property="og:image" content="assets/img/hero-placeholder.jpg" />

  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Poppins:wght@600;700;800&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="assets/css/style.css" />
</head>
<body>
  <a class="skip-link" href="#main-content">Skip to content</a>

  <!-- Top Utility Bar -->
  <div class="topbar topbar--enhanced">
    <div class="container topbar__inner">
      <div class="topbar__left">
        <span class="topbar__item">📍 Nagpur, India</span>
        <a class="topbar__item" href="tel:+918799996171">📞 +91 8799996171</a>
        <a class="topbar__item" href="mailto:info@tawatechnology.com">✉️ info@tawatechnology.com</a>
      </div>
      <div class="topbar__right">
        <a class="topbar__pill" href="contact.php">Enquiry Form</a>
        <a class="topbar__pill topbar__pill--whatsapp" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">WhatsApp</a>
      </div>
    </div>
  </div>

  <!-- Main Header -->
  <header class="site-header" id="site-header">
    <div class="container header__inner">
      <a href="index.php" class="brand" aria-label="Tawa Technology home">
        <img src="assets/img/logo.webp" alt="Tawa Technology logo" class="brand__logo" />
        <div class="brand__text">
          <span class="brand__name">Tawa Technology</span>
          <span class="brand__tagline">Empowering Businesses &amp; Students</span>
        </div>
      </a>

      <button
        class="nav-toggle"
        id="navToggle"
        aria-expanded="false"
        aria-controls="primaryNav"
        aria-label="Open navigation menu"
      >
        <span></span>
        <span></span>
        <span></span>
      </button>

      <nav class="primary-nav" id="primaryNav" aria-label="Primary navigation">
        <ul class="menu">
          <li><a class="" href="index.php">Home</a></li>

          <li><a class="" href="software.php">Software Solutions</a></li>

          <!-- Dropdown-ready item -->
          <li class="has-dropdown">
            <button class="menu-btn " type="button" aria-expanded="false">
              Products
              <span class="caret" aria-hidden="true">▾</span>
            </button>
            <div class="dropdown" role="menu" aria-label="Products submenu">
              <a href="products.php">All Products</a>
              <a href="products.php#advocate-diary">Advocate Diary</a>
              <a href="products.php#micro-finance">Micro Finance</a>
              <a href="products.php#custom-apps">Custom Business Apps</a>
            </div>
          </li>

          <li class="has-dropdown">
            <button class="menu-btn is-active" type="button" aria-expanded="false">
              Training
              <span class="caret" aria-hidden="true">▾</span>
            </button>
            <div class="dropdown" role="menu" aria-label="Training submenu">
              <a href="training.php">All Courses</a>
              <a href="training.php#java-full-stack">Java Full Stack</a>
              <a href="training.php#core-java">Core Java</a>
              <a href="training.php#sql-powerbi">SQL / Power BI</a>
              <a href="training.php#web-development">Web Development</a>
            </div>
          </li>

          <li><a class="" href="case-studies.php">Case Studies</a></li>
          <li><a class="" href="about.php">About</a></li>
          <li><a class="" href="blog.php">Resources</a></li>
          <li><a class="" href="contact.php">Contact</a></li>
        </ul>

        <div class="nav-cta nav-cta--desktop">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">
            Call / WhatsApp Now
          </a>
        </div>
      </nav>
    </div>
  </header>
<main id="main-content">
  <!-- Hero -->
  <section class="section hero hero--inner">
    <div class="container hero__grid">
      <div class="hero__content">
        <p class="eyebrow">Training & Courses</p>
        <h1>Real-Time, Project-Based IT Training for Students & Professionals</h1>
        <p class="hero__lead">
          Tawa Technology helps learners build job-ready skills through practical training in Java, SQL, Power BI, and Web Development — with guided learning, structured concepts, and project-oriented practice.
        </p>

        <div class="hero__actions">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">
            Call / WhatsApp Now
          </a>
          <a class="btn btn--secondary" href="/contact.php">Talk to an Expert</a>
        </div>

        <ul class="hero__trust">
          <li>Beginner to advanced learning paths</li>
          <li>Real-time and project-based approach</li>
          <li>Student + professional-friendly guidance</li>
        </ul>
      </div>

      <div class="hero__visual">
        <img src="assets/img/RealTimeProject.webp" alt="Placeholder image for IT training and students learning with projects" />
      </div>
    </div>
  </section>

  <!-- Quick CTA Banner -->
  <section class="section section--alt section--compact">
    <div class="container">
      <div class="cta-banner">
        <div class="cta-banner__content">
          <p class="eyebrow">Start With the Right Course</p>
          <h2>Not Sure Which Course to Choose?</h2>
          <p>
            Tell us your current level (beginner / intermediate / experienced) and your goal (job, upskilling, project, interview prep). We’ll suggest the right learning path.
          </p>
        </div>
        <div class="cta-banner__actions">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">WhatsApp for Guidance</a>
          <a class="btn btn--secondary" href="#training-enquiry">Send Course Enquiry</a>
        </div>
      </div>
    </div>
  </section>

  <!-- Why Tawa Training -->
  <section class="section" id="why-tawa-training">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Why Learn With Tawa Technology</p>
        <h2>Practical Learning Focused on Skills, Confidence & Real Application</h2>
        <p>
          Our training approach is designed for learners who want more than theory. We focus on understanding, implementation, and guided practice using structured learning paths.
        </p>
      </div>

      <div class="card-grid card-grid--3">
        <article class="feature-card">
          <h3>Project-Based Learning Approach</h3>
          <p>
            Learn concepts through practical exercises, mini tasks, and project-oriented implementation thinking.
          </p>
        </article>

        <article class="feature-card">
          <h3>Real-Time Guidance</h3>
          <p>
            Get practical explanations and implementation-focused support, not just theoretical definitions.
          </p>
        </article>

        <article class="feature-card">
          <h3>Structured Learning Path</h3>
          <p>
            Move from basics to advanced topics in a sequence designed to improve understanding and retention.
          </p>
        </article>

        <article class="feature-card">
          <h3>Career-Oriented Skill Building</h3>
          <p>
            Training is aligned to practical skill development useful for jobs, projects, and interviews.
          </p>
        </article>

        <article class="feature-card">
          <h3>Multiple Learner Profiles Supported</h3>
          <p>
            Suitable for students, working professionals, career switchers, and learners restarting after a gap.
          </p>
        </article>

        <article class="feature-card">
          <h3>Software + Training Expertise</h3>
          <p>
            Training benefits from real project and software development experience, improving practical relevance.
          </p>
        </article>
      </div>
    </div>
  </section>

  <!-- Learning Paths -->
  <section class="section section--alt" id="learning-paths">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Learning Paths</p>
        <h2>Choose a Path Based on Your Goal</h2>
        <p>
          These suggested paths help learners start from the right place. You can customize the path based on your background and time availability.
        </p>
      </div>

      <div class="card-grid card-grid--3">
        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">🟢</div>
          <h3>Beginner Path</h3>
          <p>Best for students or fresh learners starting from basics.</p>
          <ul class="list-check">
            <li>Core Java / Programming Fundamentals</li>
            <li>Web Development Basics</li>
            <li>SQL Fundamentals</li>
            <li>Mini Projects + Practice</li>
          </ul>
          <a class="text-link" href="#training-enquiry">Ask for Beginner Path Guidance</a>
        </article>

        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">🟡</div>
          <h3>Job-Oriented Java Path</h3>
          <p>For learners targeting Java development roles and backend skill growth.</p>
          <ul class="list-check">
            <li>Core Java → Advanced Java</li>
            <li>Database / SQL Integration</li>
            <li>Web + Backend Concepts</li>
            <li>Project-Oriented Java Full Stack Training</li>
          </ul>
          <a class="text-link" href="#java-full-stack">Explore Java Full Stack Track</a>
        </article>

        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">🔵</div>
          <h3>Upskilling / Professional Path</h3>
          <p>For professionals improving technical skills for projects, analytics, or growth.</p>
          <ul class="list-check">
            <li>SQL / Power BI for reporting and analytics</li>
            <li>Web skills for digital project support</li>
            <li>Focused modules by need</li>
            <li>Applied practice and use cases</li>
          </ul>
          <a class="text-link" href="#training-enquiry">Discuss Your Upskilling Goal</a>
        </article>
      </div>
    </div>
  </section>

  <!-- Course Catalog -->
  <section class="section" id="course-catalog">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Course Catalog</p>
        <h2>Training Programs Offered by Tawa Technology</h2>
      </div>

      <div class="course-list">
        <!-- Java Full Stack -->
        <article class="course-detail-card" id="java-full-stack">
          <div class="course-detail-card__header">
            <div>
              <span class="pill">Flagship Program</span>
              <h3>Java Full Stack</h3>
              <p>
                A structured program for learners who want end-to-end development skills with strong Java fundamentals and project-oriented training.
              </p>
            </div>
            <div class="course-detail-card__meta">
              <div><strong>Duration:</strong> Eight Months</div>
              <div><strong>Mode:</strong> Online / Offline / Hybrid</div>
              <div><strong>Level:</strong> Beginner to Intermediate (Path-based)</div>
            </div>
          </div>

          <div class="course-detail-card__body">
            <div class="course-col">
              <h4>What You Learn (High-Level)</h4>
              <ul class="list-check">
                <li>Programming foundation and Java core concepts</li>
                <li>Object-oriented programming and problem-solving</li>
                <li>Backend development concepts and application flow</li>
                <li>Database integration and SQL usage</li>
                <li>Frontend fundamentals (HTML/CSS/JS)</li>
                <li>Project-oriented implementation approach</li>
              </ul>
            </div>
            <div class="course-col">
              <h4>Best For</h4>
              <ul class="list-check">
                <li>Students targeting IT/software jobs</li>
                <li>Learners who want Java-based development skills</li>
                <li>Career switchers building structured technical foundations</li>
              </ul>

              <h4>Outcome Focus</h4>
              <ul class="list-check">
                <li>Better coding confidence</li>
                <li>Stronger concept clarity</li>
                <li>Project-oriented learning exposure</li>
              </ul>
            </div>
          </div>

          <div class="card-actions">
            <a class="btn btn--primary btn--sm" href="#fees">See Fee Structure</a>
            <a class="btn btn--secondary btn--sm" href="#training-enquiry">Enquire for Batch & Fees</a>
          </div>
        </article>

        <!-- Core Java -->
        <article class="course-detail-card" id="core-java">
          <div class="course-detail-card__header">
            <div>
              <span class="pill">Foundation Program</span>
              <h3>Core Java</h3>
              <p>
                Build a strong programming foundation with Java fundamentals, OOP concepts, and practical coding practice.
              </p>
            </div>
            <div class="course-detail-card__meta">
              <div><strong>Duration:</strong> Six Months</div>
              <div><strong>Mode:</strong> Online / Offline / Hybrid</div>
              <div><strong>Level:</strong> Beginner</div>
            </div>
          </div>

          <div class="course-detail-card__body">
            <div class="course-col">
              <h4>Key Topics (Example Structure)</h4>
              <ul class="list-check">
                <li>Java introduction and setup</li>
                <li>Variables, data types, operators</li>
                <li>Control statements and loops</li>
                <li>Methods and arrays</li>
                <li>OOP concepts (class, object, inheritance, polymorphism)</li>
                <li>Exception handling and collections basics (placeholder)</li>
              </ul>
            </div>
            <div class="course-col">
              <h4>Best For</h4>
              <ul class="list-check">
                <li>Beginners in programming</li>
                <li>Students starting Java development</li>
                <li>Learners preparing for advanced Java/full stack path</li>
              </ul>

              <h4>Outcome Focus</h4>
              <ul class="list-check">
                <li>Strong fundamentals</li>
                <li>Better coding discipline</li>
                <li>Readiness for next-level Java learning</li>
              </ul>
            </div>
          </div>

          <div class="card-actions">
            <a class="btn btn--secondary btn--sm" href="#fees">See Fee Structure</a>
            <a class="text-link" href="#training-enquiry">Ask if this is right for me</a>
          </div>
        </article>

        <!-- SQL / Power BI -->
        <article class="course-detail-card" id="sql-powerbi">
          <div class="course-detail-card__header">
            <div>
              <span class="pill">Data & Reporting</span>
              <h3>SQL / Power BI</h3>
              <p>
                Learn data querying, reporting, and dashboard creation using practical business examples and analytics-oriented thinking.
              </p>
            </div>
            <div class="course-detail-card__meta">
              <div><strong>Duration:</strong> Two Months</div>
              <div><strong>Mode:</strong> Online / Offline / Hybrid</div>
              <div><strong>Level:</strong> Beginner to Intermediate</div>
            </div>
          </div>

          <div class="course-detail-card__body">
            <div class="course-col">
              <h4>What You Learn</h4>
              <ul class="list-check">
                <li>SQL basics to practical querying</li>
                <li>Filtering, joins, aggregations, reporting logic</li>
                <li>Data handling for business use cases</li>
                <li>Power BI dashboard fundamentals </li>
                <li>Visualization and reporting structure</li>
              </ul>
            </div>
            <div class="course-col">
              <h4>Best For</h4>
              <ul class="list-check">
                <li>Students interested in data/reporting roles</li>
                <li>Working professionals using data in business operations</li>
                <li>Analyst-focused upskilling</li>
              </ul>

              <h4>Outcome Focus</h4>
              <ul class="list-check">
                <li>Practical SQL confidence</li>
                <li>Reporting and dashboard understanding</li>
                <li>Business-oriented analytics skills</li>
              </ul>
            </div>
          </div>

          <div class="card-actions">
            <a class="btn btn--secondary btn--sm" href="#fees">See Fee Structure</a>
            <a class="text-link" href="#training-enquiry">Enquire for this course</a>
          </div>
        </article>

        <!-- Web Development -->
        <article class="course-detail-card" id="web-development">
          <div class="course-detail-card__header">
            <div>
              <span class="pill">Frontend Foundation</span>
              <h3>Web Development</h3>
              <p>
                Learn HTML, CSS, JavaScript, and responsive layout building through hands-on website practice and project exercises.
              </p>
            </div>
            <div class="course-detail-card__meta">
              <div><strong>Duration:</strong> Three Months</div>
              <div><strong>Mode:</strong> Online / Offline / Hybrid</div>
              <div><strong>Level:</strong> Beginner</div>
            </div>
          </div>

          <div class="course-detail-card__body">
            <div class="course-col">
              <h4>What You Learn</h4>
              <ul class="list-check">
                <li>HTML5 structure and semantic markup</li>
                <li>CSS3 styling and layout fundamentals</li>
                <li>Responsive design basics</li>
                <li>JavaScript fundamentals (placeholder depth)</li>
                <li>Multi-section website building practice</li>
              </ul>
            </div>
            <div class="course-col">
              <h4>Best For</h4>
              <ul class="list-check">
                <li>Students starting web development</li>
                <li>Beginners building frontend skills</li>
                <li>Learners supporting website projects</li>
              </ul>

              <h4>Outcome Focus</h4>
              <ul class="list-check">
                <li>Website building confidence</li>
                <li>Responsive UI understanding</li>
                <li>Practical frontend foundation</li>
              </ul>
            </div>
          </div>

          <div class="card-actions">
            <a class="btn btn--secondary btn--sm" href="#fees">See Fee Structure</a>
            <a class="text-link" href="#training-enquiry">Enquire for this course</a>
          </div>
        </article>
      </div>
    </div>
  </section>

  <!-- Fee Structure -->
  <section class="section section--alt" id="fees">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Course Fees</p>
        <h2>Course Fee Structure</h2>
      </div>

      <div class="table-wrap">
        <table class="pricing-table">
          <thead>
            <tr>
              <th>Course</th>
              <th>Duration</th>
              <th>Mode</th>
              <th>Fees (₹)</th>
              <th>Installment Option</th>
              <th>CTA</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Java Full Stack</td>
              <td>8 Months</td>
              <td>Offline</td>
              <td>₹ 30,000</td>
              <td>Available</td>
              <td><a class="text-link" href="#training-enquiry">Enquire</a></td>
            </tr>
            <tr>
              <td>Core Java</td>
              <td>6 Months</td>
              <td>Offline</td>
              <td>₹ 3,500</td>
              <td>Not Available</td>
              <td><a class="text-link" href="#training-enquiry">Enquire</a></td>
            </tr>
            <tr>
              <td>SQL / Power BI</td>
              <td>2 Months</td>
              <td>Offline</td>
              <td>₹ 5,000</td>
              <td>Available</td>
              <td><a class="text-link" href="#training-enquiry">Enquire</a></td>
            </tr>
            <tr>
              <td>Web Development</td>
              <td>3 Months</td>
              <td>Offline</td>
              <td>₹ 6,000</td>
              <td>Available</td>
              <td><a class="text-link" href="#training-enquiry">Enquire</a></td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="training-note">
        <p>
          <strong>Need help selecting the right course?</strong> Contact us with your current level and goal. We’ll guide you to a suitable program.
        </p>
        <a class="btn btn--ghost btn--sm" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">WhatsApp for Course Guidance</a>
      </div>
    </div>
  </section>

  <!-- Batch Modes / Format -->
  <section class="section" id="batch-format">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Batch Format & Learning Support</p>
        <h2>Flexible Learning Formats for Different Learners</h2>
      </div>

      <div class="card-grid card-grid--3">
        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">🏫</div>
          <h3>Offline / Classroom</h3>
          <p>
            For learners who prefer direct classroom interaction and in-person guidance.
          </p>
          <ul class="list-check">
            <li>Scheduled batches</li>
            <li>Practical explanation style</li>
            <li>Guided exercises</li>
          </ul>
        </article>

        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">💻</div>
          <h3>Online / Live Sessions</h3>
          <p>
            For learners who want flexibility and live interactive training from anywhere.
          </p>
          <ul class="list-check">
            <li>Live guided sessions</li>
            <li>Doubt support</li>
            <li>Practical coding guidance</li>
          </ul>
        </article>

        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">🔀</div>
          <h3>Hybrid / Flexible Support</h3>
          <p>
            Combine structured training with flexible support based on learner and batch needs.
          </p>
          <ul class="list-check">
            <li>Custom learning path discussion</li>
            <li>Batch compatibility support</li>
            <li>Goal-based direction</li>
          </ul>
        </article>
      </div>
    </div>
  </section>

  <!-- Student Projects / Outcomes -->
  <section class="section section--alt" id="student-outcomes">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Projects & Outcomes</p>
        <h2>Learning Through Practice and Project Thinking</h2>
        <p>
          Replace these placeholders with real student projects, mini-project examples, or portfolio outputs from your training programs.
        </p>
      </div>

      <div class="card-grid card-grid--3">
        <article class="case-card">
          <img src="assets/img/CoreJavaMiniProject.webp" alt="Placeholder image for student project 1" />
          <div class="case-card__body">
            <h3>Java Mini Project</h3>
            <p><strong>Focus:</strong> Core Java concepts and logic implementation</p>
            <p><strong>Skills Used:</strong> OOP, methods, collections</p>
            <p><strong>Outcome:</strong> Better coding confidence and concept application</p>
            <a class="text-link" href="#training-enquiry">Enquire for Java Training</a>
          </div>
        </article>

        <article class="case-card">
          <img src="assets/img/SQL_PowerBI_Case.webp" alt="Placeholder image for student project 2" />
          <div class="case-card__body">
            <h3>SQL / Power BI Practice Case</h3>
            <p><strong>Focus:</strong> Querying, reporting, and dashboard thinking</p>
            <p><strong>Skills Used:</strong> SQL joins, aggregations, visualization</p>
            <p><strong>Outcome:</strong> Better reporting and analytics confidence</p>
            <a class="text-link" href="#training-enquiry">Enquire for SQL / Power BI</a>
          </div>
        </article>

        <article class="case-card">
          <img src="assets/img/ResponsiveWebsiteProject.webp" alt="Placeholder image for student project 3" />
          <div class="case-card__body">
            <h3>Responsive Website Project</h3>
            <p><strong>Focus:</strong> Frontend structure and responsive layout</p>
            <p><strong>Skills Used:</strong> HTML, CSS, JavaScript basics</p>
            <p><strong>Outcome:</strong> Practical website building readiness</p>
            <a class="text-link" href="#training-enquiry">Enquire for Web Development</a>
          </div>
        </article>
      </div>
    </div>
  </section>

  <!-- Corporate / College Training -->
  <section class="section" id="corporate-college-training">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Colleges & Corporate Training</p>
        <h2>Training Support for Institutions, Colleges & Organizations</h2>
        <p>
          We also support group training requirements for colleges and organizations.</p>
      </div>

      <div class="card-grid card-grid--2">
        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">🏢</div>
          <h3>Corporate / Team Upskilling </h3>
          <p>
            Practical technical training modules for teams needing foundational or role-specific skill improvement.
          </p>
          <ul class="list-check">
            <li>Custom module selection</li>
            <li>Batch-based delivery</li>
            <li>Training goals alignment discussion</li>
          </ul>
          <a class="text-link" href="#training-enquiry">Discuss Team Training</a>
        </article>

        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">🎓</div>
          <h3>College Training Programs</h3>
          <p>
            Skill-based training support for students through practical and project-oriented sessions.
          </p>
          <ul class="list-check">
            <li>Java / Web / SQL tracks</li>
            <li>Project-oriented sessions</li>
            <li>Skill-building focused structure</li>
          </ul>
          <a class="text-link" href="#training-enquiry">Discuss College Training</a>
        </article>
      </div>
    </div>
  </section>

  <!-- Testimonials -->
  <section class="section section--alt" id="training-testimonials">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Student Testimonials</p>
        <h2>What Learners Say </h2>
      </div>

      <div class="card-grid card-grid--3">
        <blockquote class="testimonial-card">
          <p>
            “The training approach was practical and helped me understand concepts clearly instead of only memorizing.”
          </p>
          <footer>— Student (Rahul Jain)</footer>
        </blockquote>

        <blockquote class="testimonial-card">
          <p>
            “I liked the project-based guidance. It improved my confidence in applying Java and database concepts.”
          </p>
          <footer>— Learner (Priya Lade)</footer>
        </blockquote>

        <blockquote class="testimonial-card">
          <p>
            “The course structure and explanations were helpful for building a strong foundation before interviews.”
          </p>
          <footer>— Professional (Anamika Sahu)</footer>
        </blockquote>
      </div>
    </div>
  </section>

  <!-- FAQ -->
  <section class="section" id="training-faq">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Training FAQ</p>
        <h2>Frequently Asked Questions (Students & Professionals)</h2>
      </div>

      <div class="faq-list">
        <details>
          <summary>Which course is best for a complete beginner?</summary>
          <p>
            It depends on your goal. Core Java and Web Development are common starting points. If your goal is Java Full Stack, we can guide you on the best starting sequence.
          </p>
        </details>

        <details>
          <summary>Do you provide project-based training?</summary>
          <p>
            Yes. Our training approach is practical and project-oriented to help learners understand real usage and implementation thinking.
          </p>
        </details>

        <details>
          <summary>Can working professionals join these courses?</summary>
          <p>
            Yes. We support learners with different backgrounds, including working professionals and career switchers.
          </p>
        </details>

        <details>
          <summary>How can I get course fees and batch details?</summary>
          <p>
            You can call, WhatsApp, or submit the enquiry form on this page. We’ll share the latest course fees, batch schedule, and options.
          </p>
        </details>

        <details>
          <summary>Do you help learners choose the right course path?</summary>
          <p>
            Yes. Share your current level and goal, and we’ll help you choose the most suitable learning path.
          </p>
        </details>

        <details>
          <summary>Do you offer training for colleges or organizations?</summary>
          <p>
            Yes. College and corporate training support can be discussed based on topic, batch size, and training objectives.
          </p>
        </details>
      </div>
    </div>
  </section>

  <!-- Final CTA + Training Enquiry -->
  <section class="section contact-section" id="training-enquiry">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Course Enquiry</p>
        <h2>Ready to Start Learning? Let’s Choose the Right Course for You.</h2>
        <p>
          Whether you’re a beginner, a job seeker, or a working professional, Tawa Technology can help you build the right skills with a practical learning plan.
        </p>
      </div>

      <div class="contact-grid">
        <div class="contact-card">
          <h3>Quick Contact for Course Guidance</h3>
          <ul class="contact-list">
            <li><strong>Phone:</strong> <a href="tel:+918799996171">+91 8799996171</a></li>
            <li><strong>WhatsApp:</strong> <a href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">Start WhatsApp Chat</a></li>
            <li><strong>Email:</strong> <a href="mailto:info@tawatechnology.com">info@tawatechnology.com</a></li>
            <li><strong>Location:</strong> Panchwati Park, Hingna, Nagpur, India</li>
            <li><strong>Best First Step:</strong> Share your goal + current level on WhatsApp (placeholder guidance)</li>
          </ul>

          <div class="contact-actions">
            <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">Call / WhatsApp Now</a>
            <a class="btn btn--secondary" href="contact.php">Talk to an Expert</a>
          </div>
        </div>

        <form class="contact-form" action="#" method="post" novalidate>
          <h3>Send a Training Enquiry</h3>

          <div class="form-row form-row--2">
            <div>
              <label for="studentName">Full Name *</label>
              <input type="text" id="studentName" name="studentName" placeholder="Enter your name" required />
            </div>
            <div>
              <label for="studentPhone">Phone / WhatsApp *</label>
              <input type="tel" id="studentPhone" name="studentPhone" placeholder="+91 XXXXX XXXXX" required />
            </div>
          </div>

          <div class="form-row form-row--2">
            <div>
              <label for="studentEmail">Email *</label>
              <input type="email" id="studentEmail" name="studentEmail" placeholder="you@example.com" required />
            </div>
            <div>
              <label for="learnerType">I am a *</label>
              <select id="learnerType" name="learnerType" required>
                <option value="">Select option</option>
                <option value="student">Student</option>
                <option value="job-seeker">Job Seeker</option>
                <option value="working-professional">Working Professional</option>
                <option value="career-switcher">Career Switcher</option>
                <option value="other">Other</option>
              </select>
            </div>
          </div>

          <div class="form-row form-row--2">
            <div>
              <label for="courseInterest">Course Interest *</label>
              <select id="courseInterest" name="courseInterest" required>
                <option value="">Select course</option>
                <option value="java-full-stack">Java Full Stack</option>
                <option value="core-java">Core Java</option>
                <option value="sql-powerbi">SQL / Power BI</option>
                <option value="web-development">Web Development</option>
                <option value="not-sure">Not Sure Yet</option>
              </select>
            </div>
            <div>
              <label for="currentLevel">Current Level *</label>
              <select id="currentLevel" name="currentLevel" required>
                <option value="">Select level</option>
                <option value="beginner">Beginner</option>
                <option value="basic-knowledge">Basic Knowledge</option>
                <option value="intermediate">Intermediate</option>
                <option value="professional-upskilling">Professional Upskilling</option>
              </select>
            </div>
          </div>

          <div class="form-row form-row--2">
            <div>
              <label for="learningMode">Preferred Mode (Optional)</label>
              <select id="learningMode" name="learningMode">
                <option value="">Select mode</option>
                <option value="offline">Offline / Classroom</option>
                <option value="online-live">Online / Live</option>
                <option value="hybrid">Hybrid</option>
                <option value="not-sure">Not Sure</option>
              </select>
            </div>
            <div>
              <label for="goalType">Primary Goal (Optional)</label>
              <select id="goalType" name="goalType">
                <option value="">Select goal</option>
                <option value="job">Get a Job</option>
                <option value="upskilling">Upskill for Current Role</option>
                <option value="project-building">Build Projects</option>
                <option value="interview-prep">Interview Preparation</option>
                <option value="college-support">College Skill Development</option>
              </select>
            </div>
          </div>

          <div class="form-row">
            <label for="studentMessage">Message / Learning Goal *</label>
            <textarea id="studentMessage" name="studentMessage" rows="6" placeholder="Tell us your current background, the course you want, and your goal..." required></textarea>
          </div>

          <div class="form-row checkbox-row">
            <input type="checkbox" id="trainingConsent" name="trainingConsent" required />
            <label for="trainingConsent">I agree to be contacted by Tawa Technology regarding this training enquiry.</label>
          </div>

          <button type="submit" class="btn btn--primary">Send Training Enquiry</button>
          <p class="form-note">
            Placeholder form setup. Connect later to Formspree, Netlify Forms, or PHP mailer on your hosting.
          </p>
        </form>
      </div>
    </div>
  </section>
</main>

  <!-- Footer -->
  <footer class="site-footer">
    <div class="container footer__grid">
      <div class="footer__col footer__col--brand">
        <a href="index.php" class="brand brand--footer">
          <img src="assets/img/logo.webp" alt="Tawa Technology logo" class="brand__logo" />
          <div class="brand__text">
            <span class="brand__name">Tawa Technology</span>
            <span class="brand__tagline">Empowering Businesses &amp; Students</span>
          </div>
        </a>

        <p class="footer__about">
          Tawa Technology helps businesses digitize operations through practical software solutions and helps students build job-ready skills through project-based IT training.
        </p>

        <div class="footer__quick-contact">
          <a href="tel:+918799996171">📞 +91 8799996171</a>
          <a href="mailto:info@tawatechnology.com">✉️ info@tawatechnology.com</a>
          <a href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">💬 WhatsApp Chat</a>
          <span>📍 Nagpur, India</span>
        </div>
      </div>

      <div class="footer__col">
        <h3>Software Solutions</h3>
        <ul>
          <li><a href="/software.php">Custom Web Applications</a></li>
          <li><a href="/software.php">Java / Enterprise Solutions</a></li>
          <li><a href="/software.php">Business Websites</a></li>
          <li><a href="/software.php">Process Digitization</a></li>
          <li><a href="/software.php">SEO & Digital Consulting</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Products</h3>
        <ul>
          <li><a href="products.php#advocate-diary">Advocate Diary</a></li>
          <li><a href="products.php#micro-finance">Micro Finance Management</a></li>
          <li><a href="products.php#custom-apps">Custom Business Apps</a></li>
          <li><a href="products.php">Product Demo Request</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Training & Courses</h3>
        <ul>
          <li><a href="training.php#java-full-stack">Java Full Stack</a></li>
          <li><a href="training.php#core-java">Core Java</a></li>
          <li><a href="training.php#sql-powerbi">SQL / Power BI</a></li>
          <li><a href="training.php#web-development">Web Development</a></li>
          <li><a href="training.php#fees">Course Fees</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Company</h3>
        <ul>
          <li><a href="about.php">About Tawa Technology</a></li>
          <li><a href="case-studies.php">Case Studies</a></li>
          <li><a href="blog.php">Resources / Blog</a></li>
          <li><a href="faq.php">FAQ</a></li>
          <li><a href="contact.php">Contact / Enquiry</a></li>
        </ul>
      </div>
    </div>

    <div class="container footer__bottom">
      <p>© <span id="year"></span> Tawa Technology. All rights reserved.</p>
      <div class="footer__links">
        <a href="privacy-policy.php">Privacy Policy</a>
        <a href="terms.php">Terms</a>
        <a href="contact.php">Contact</a>
      </div>
    </div>
  </footer>

  <!-- Mobile Sticky CTA Bar -->
  <div class="mobile-cta" role="region" aria-label="Quick contact actions">
    <a class="mobile-cta__btn" href="tel:+918799996171" aria-label="Call Tawa Technology">
      📞 Call
    </a>
    <a class="mobile-cta__btn mobile-cta__btn--whatsapp"
      href="https://wa.me/918799996171"
      target="_blank" rel="noopener noreferrer"
      aria-label="WhatsApp Tawa Technology">
      WhatsApp
    </a>
  </div>
  <script src="assets/js/main.js"></script>
  </body>

  </html>