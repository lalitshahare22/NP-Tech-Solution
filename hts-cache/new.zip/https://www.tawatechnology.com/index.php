<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Tawa Technology | Software Solutions &amp; IT Training in Nagpur</title>
  <meta name="description" content="Tawa Technology provides software development, products, and real-time project-based IT training in Nagpur." />
  <meta name="theme-color" content="#003399" />

  <!-- Open Graph (basic, reusable) -->
  <meta property="og:title" content="Tawa Technology | Software Solutions &amp; IT Training in Nagpur" />
  <meta property="og:description" content="Tawa Technology provides software development, products, and real-time project-based IT training in Nagpur." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://www.tawatechnology.com/" />
  <meta property="og:image" content="assets/img/hero-placeholder.jpg" />

  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Poppins:wght@600;700;800&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="assets/css/style.css" />
</head>
<body>
  <a class="skip-link" href="#main-content">Skip to content</a>

  <!-- Top Utility Bar -->
  <div class="topbar topbar--enhanced">
    <div class="container topbar__inner">
      <div class="topbar__left">
        <span class="topbar__item">📍 Nagpur, India</span>
        <a class="topbar__item" href="tel:+918799996171">📞 +91 8799996171</a>
        <a class="topbar__item" href="mailto:info@tawatechnology.com">✉️ info@tawatechnology.com</a>
      </div>
      <div class="topbar__right">
        <a class="topbar__pill" href="contact.php">Enquiry Form</a>
        <a class="topbar__pill topbar__pill--whatsapp" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">WhatsApp</a>
      </div>
    </div>
  </div>

  <!-- Main Header -->
  <header class="site-header" id="site-header">
    <div class="container header__inner">
      <a href="index.php" class="brand" aria-label="Tawa Technology home">
        <img src="assets/img/logo.webp" alt="Tawa Technology logo" class="brand__logo" />
        <div class="brand__text">
          <span class="brand__name">Tawa Technology</span>
          <span class="brand__tagline">Empowering Businesses &amp; Students</span>
        </div>
      </a>

      <button
        class="nav-toggle"
        id="navToggle"
        aria-expanded="false"
        aria-controls="primaryNav"
        aria-label="Open navigation menu"
      >
        <span></span>
        <span></span>
        <span></span>
      </button>

      <nav class="primary-nav" id="primaryNav" aria-label="Primary navigation">
        <ul class="menu">
          <li><a class="is-active" href="index.php">Home</a></li>

          <li><a class="" href="software.php">Software Solutions</a></li>

          <!-- Dropdown-ready item -->
          <li class="has-dropdown">
            <button class="menu-btn " type="button" aria-expanded="false">
              Products
              <span class="caret" aria-hidden="true">▾</span>
            </button>
            <div class="dropdown" role="menu" aria-label="Products submenu">
              <a href="products.php">All Products</a>
              <a href="products.php#advocate-diary">Advocate Diary</a>
              <a href="products.php#micro-finance">Micro Finance</a>
              <a href="products.php#custom-apps">Custom Business Apps</a>
            </div>
          </li>

          <li class="has-dropdown">
            <button class="menu-btn " type="button" aria-expanded="false">
              Training
              <span class="caret" aria-hidden="true">▾</span>
            </button>
            <div class="dropdown" role="menu" aria-label="Training submenu">
              <a href="training.php">All Courses</a>
              <a href="training.php#java-full-stack">Java Full Stack</a>
              <a href="training.php#core-java">Core Java</a>
              <a href="training.php#sql-powerbi">SQL / Power BI</a>
              <a href="training.php#web-development">Web Development</a>
            </div>
          </li>

          <li><a class="" href="case-studies.php">Case Studies</a></li>
          <li><a class="" href="about.php">About</a></li>
          <li><a class="" href="blog.php">Resources</a></li>
          <li><a class="" href="contact.php">Contact</a></li>
        </ul>

        <div class="nav-cta nav-cta--desktop">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">
            Call / WhatsApp Now
          </a>
        </div>
      </nav>
    </div>
  </header>
<main id="main-content">
  <!-- Hero -->
  <section class="hero section" id="home">
    <div class="container hero__grid">
      <div class="hero__content">
        <p class="eyebrow">Software + Training | Nagpur, India</p>
        <h1>Modern Software Solutions &amp; Real-Time IT Training for Businesses and Students</h1>
        <p class="hero__lead">
          Tawa Technology helps small and medium businesses digitize operations with practical software solutions — and helps students and professionals build job-ready skills through project-based training.
        </p>

        <div class="hero__actions">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">
            Call / WhatsApp Now
          </a>
          <a class="btn btn--ghost" href="#contact">Talk to an Expert</a>
        </div>

        <ul class="hero__trust">
          <li>Practical, outcome-focused approach</li>
          <li>Software + training expertise</li>
          <li>SMB-friendly engagement</li>
        </ul>
      </div>

      <div class="hero__visual">
        <img src="assets/img/home_hero.webp" alt="Placeholder image for Tawa Technology software and training" />
      </div>
    </div>

    <div class="container hero-paths">
      <article class="path-card">
        <h2>For Businesses</h2>
        <p>
          Need software, a business website, or process automation? We build practical solutions designed around your workflow.
        </p>
        <a class="btn btn--secondary btn--sm" href="#software">Explore Software Solutions</a>
      </article>

      <article class="path-card">
        <h2>For Students</h2>
        <p>
          Want job-ready IT skills with real-time project-based training? Learn Java, SQL, Power BI, and web development.
        </p>
        <a class="btn btn--secondary btn--sm" href="#training">Explore Training &amp; Courses</a>
      </article>
    </div>
  </section>

  <!-- What We Do -->
  <section class="section section--alt" id="services-overview">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">What We Do</p>
        <h2>One Company. Two Growth Paths. Multiple Technology Solutions.</h2>
        <p>
          Tawa Technology combines software development, practical training, and digital services to support business growth and career growth under one trusted brand.
        </p>
      </div>

      <div class="card-grid card-grid--3">
        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">💻</div>
          <h3>Software Development &amp; IT Solutions</h3>
          <p>
            Custom software and web solutions designed to solve real operational problems and improve business efficiency.
          </p>
          <ul class="list-check">
            <li>Custom Web Applications</li>
            <li>Java / Enterprise Applications</li>
            <li>Business Process Automation</li>
            <li>Domain-Specific Solutions</li>
          </ul>
          <a href="#software" class="text-link">Request a Software Consultation</a>
        </article>

        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">🎓</div>
          <h3>Training &amp; Education</h3>
          <p>
            Project-based IT training for students and professionals who want practical skills and industry-relevant experience.
          </p>
          <ul class="list-check">
            <li>Java Full Stack</li>
            <li>Core Java</li>
            <li>SQL / Power BI</li>
            <li>Web Development</li>
          </ul>
          <a href="#training" class="text-link">View Courses &amp; Training</a>
        </article>

        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">🌐</div>
          <h3>Digital &amp; Web Services</h3>
          <p>
            Website design, development, and digital consulting for small businesses looking to build trust and generate leads online.
          </p>
          <ul class="list-check">
            <li>Business Websites</li>
            <li>SEO &amp; Digital Consulting</li>
            <li>Landing Pages</li>
            <li>Technical Support</li>
          </ul>
          <a href="#contact" class="text-link">Discuss Your Website Project</a>
        </article>
      </div>
    </div>
  </section>

  <!-- Software Solutions -->
  <section class="section" id="software">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Business Solutions</p>
        <h2>Software &amp; Digital Solutions for Small and Medium Businesses</h2>
        <p>
          We focus on practical solutions — clear requirements, workable design, and reliable delivery for real business needs.
        </p>
      </div>

      <div class="card-grid card-grid--3">
        <article class="feature-card">
          <h3>Custom Web Applications</h3>
          <p>Build systems aligned to your workflows, records, and reporting needs.</p>
        </article>
        <article class="feature-card">
          <h3>Java / Enterprise Solutions</h3>
          <p>Scalable backend-oriented solutions using robust application design principles.</p>
        </article>
        <article class="feature-card">
          <h3>Business Websites</h3>
          <p>Professional, responsive websites designed for trust, clarity, and enquiries.</p>
        </article>
        <article class="feature-card">
          <h3>Process Digitization</h3>
          <p>Reduce manual tracking and improve operational visibility with digital workflows.</p>
        </article>
        <article class="feature-card">
          <h3>Product Customization</h3>
          <p>Adapt domain-specific modules for your unique use case and operations.</p>
        </article>
        <article class="feature-card">
          <h3>SEO &amp; Digital Consulting</h3>
          <p>Improve local discoverability and lead quality for service-oriented businesses.</p>
        </article>
      </div>

      <div class="cta-inline">
        <a class="btn btn--primary" href="#contact">Discuss Your Requirement</a>
        <a class="btn btn--secondary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">
          Talk to an Expert
        </a>
      </div>
    </div>
  </section>

  <!-- Products -->
  <section class="section section--alt" id="products">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Products</p>
        <h2>Featured Products &amp; Domain Solutions</h2>
        <p>
          We develop practical products and solution frameworks based on real business requirements in specific domains.
        </p>
      </div>

      <div class="product-grid">
        <article class="product-card">
          <img src="assets/img/advocate_diary.webp" alt="Placeholder screenshot for Advocate Diary product" />
          <div class="product-card__body">
            <span class="pill">Legal Domain</span>
            <h3>Advocate Diary</h3>
            <p>
              A solution-oriented platform concept to support legal case records, practice tracking, and day-to-day office organization.
            </p>
            <div class="card-actions">
              <a class="btn btn--secondary btn--sm" href="#contact">Request Demo</a>
              <a class="text-link" href="#contact">View Product Details</a>
            </div>
          </div>
        </article>

        <article class="product-card">
          <img src="assets/img/MicroFinanceSocietyManagement.webp" alt="Placeholder screenshot for Micro Finance product" />
          <div class="product-card__body">
            <span class="pill">Finance / Society</span>
            <h3>Micro Finance / Society Management</h3>
            <p>
              A domain-focused system approach for member management, transactions, workflows, and reporting support.
            </p>
            <div class="card-actions">
              <a class="btn btn--secondary btn--sm" href="#contact">Request Demo</a>
              <a class="text-link" href="#contact">Discuss Requirements</a>
            </div>
          </div>
        </article>

        <article class="product-card">
          <img src="assets/img/CustomBusinessApplication.webp" alt="Placeholder screenshot for custom business app product" />
          <div class="product-card__body">
            <span class="pill">Custom Development</span>
            <h3>Custom Business Application</h3>
            <p>
              Need a software solution built around your process? We design and develop tailored systems for your use case.
            </p>
            <div class="card-actions">
              <a class="btn btn--secondary btn--sm" href="#contact">Request a Quote</a>
              <a class="text-link" href="#contact">Talk to an Expert</a>
            </div>
          </div>
        </article>
      </div>
    </div>
  </section>

  <!-- Training -->
  <section class="section" id="training">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Training & Courses</p>
        <h2>Real-Time, Project-Based Training for Students &amp; Professionals</h2>
        <p>
          Our programs build confidence through guided learning, practical exercises, and project-oriented thinking — not just theory.
        </p>
      </div>

      <div class="card-grid card-grid--2">
        <article class="course-card">
          <h3>Java Full Stack</h3>
          <p>A structured pathway for learners who want strong backend and application development skills.</p>
          <ul class="list-check">
            <li>Core to Advanced Java Concepts</li>
            <li>Backend Development Fundamentals</li>
            <li>Database Integration</li>
            <li>Project-Oriented Training</li>
          </ul>
          <div class="card-actions">
            <a class="btn btn--secondary btn--sm" href="#contact">Enquire for Course & Fees</a>
          </div>
        </article>

        <article class="course-card">
          <h3>Core Java</h3>
          <p>Build a strong programming foundation with object-oriented thinking and problem-solving practice.</p>
          <ul class="list-check">
            <li>Java Fundamentals</li>
            <li>OOP Concepts</li>
            <li>Collections & Exceptions</li>
            <li>Foundation for Advanced Learning</li>
          </ul>
          <div class="card-actions">
            <a class="btn btn--secondary btn--sm" href="#contact">View Course Details</a>
          </div>
        </article>

        <article class="course-card">
          <h3>SQL / Power BI</h3>
          <p>Learn data querying, reporting, and dashboard creation with practical business data examples.</p>
          <ul class="list-check">
            <li>SQL Querying & Data Handling</li>
            <li>Reports & Analytics Basics</li>
            <li>Power BI Dashboards</li>
            <li>Business Use Cases</li>
          </ul>
          <div class="card-actions">
            <a class="btn btn--secondary btn--sm" href="#contact">View Course Details</a>
          </div>
        </article>

        <article class="course-card">
          <h3>Web Development</h3>
          <p>Learn HTML, CSS, JavaScript, and responsive website building through hands-on practice.</p>
          <ul class="list-check">
            <li>HTML5 / CSS3 / JavaScript</li>
            <li>Responsive Layouts</li>
            <li>Project-Based Practice</li>
            <li>Foundation for UI Development</li>
          </ul>
          <div class="card-actions">
            <a class="btn btn--secondary btn--sm" href="#contact">Explore Training</a>
          </div>
        </article>
      </div>

      <div class="training-note">
        <p><strong>Not sure where to start?</strong> We’ll help you choose the right course based on your current level and career goal.</p>
        <a class="btn btn--ghost btn--sm" href="#contact">Talk to an Expert</a>
      </div>
    </div>
  </section>

  <!-- Why Choose -->
  <section class="section section--alt" id="about">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Why Choose Tawa Technology</p>
        <h2>Practical Solutions. Professional Guidance. Real-World Focus.</h2>
        <p>
          We combine technical implementation experience with training expertise to deliver value for both businesses and learners.
        </p>
      </div>

      <div class="card-grid card-grid--3">
        <article class="feature-card">
          <h3>Practical Problem-Solving</h3>
          <p>We focus on solving real operational and learning challenges.</p>
        </article>
        <article class="feature-card">
          <h3>Software + Training Expertise</h3>
          <p>Training is informed by real projects and implementation thinking.</p>
        </article>
        <article class="feature-card">
          <h3>Project-Based Learning</h3>
          <p>Learners gain confidence through guided practical work.</p>
        </article>
        <article class="feature-card">
          <h3>Business-Oriented Design</h3>
          <p>Solutions are aligned with workflows, usability, and outcomes.</p>
        </article>
        <article class="feature-card">
          <h3>Nagpur-Based Support</h3>
          <p>Local availability with professional communication and execution.</p>
        </article>
        <article class="feature-card">
          <h3>Flexible Engagement</h3>
          <p>From websites to custom applications to training programs.</p>
        </article>
      </div>

      <div class="stats-grid">
        <div class="stat-card"><strong>100+</strong><span>Projects / Implementations</span></div>
        <div class="stat-card"><strong>15+</strong><span>Students Trained</span></div>
        <div class="stat-card"><strong>5+</strong><span>Domains Served</span></div>
        <div class="stat-card"><strong>13+</strong><span>Years of Experience</span></div>
      </div>
    </div>
  </section>

  <!-- Case Studies -->
  <section class="section" id="case-studies">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Case Studies / Projects</p>
        <h2>Selected Projects &amp; Use Cases</h2>
        <p>
          Showcase your real projects here using a simple problem → solution → outcome format. (Replace placeholders with actual project details.)
        </p>
      </div>

      <div class="card-grid card-grid--3">
        <article class="case-card">
          <img src="assets/img/SmallBusinessDigitizationProject.webp" alt="Placeholder image for case study 1" />
          <div class="case-card__body">
            <h3>Small Business Digitization Project</h3>
            <p><strong>Problem:</strong> Manual tracking and reporting inefficiencies.</p>
            <p><strong>Solution:</strong> Structured workflow-oriented digital system concept.</p>
            <p><strong>Outcome:</strong> Better record visibility and process clarity.</p>
            <a class="text-link" href="#contact">Discuss Similar Requirement</a>
          </div>
        </article>

        <article class="case-card">
          <img src="assets/img/LegalWorkflowSolutionConcept.webp" alt="Placeholder image for case study 2" />
          <div class="case-card__body">
            <h3>Legal Workflow Solution Concept</h3>
            <p><strong>Problem:</strong> Case-related tracking and office coordination challenges.</p>
            <p><strong>Solution:</strong> Domain-specific legal record management approach.</p>
            <p><strong>Outcome:</strong> Improved organization and operational support.</p>
            <a class="text-link" href="#contact">Request Product Demo</a>
          </div>
        </article>

        <article class="case-card">
          <img src="assets/img/TrainingProjectBasedLearningModel.webp" alt="Placeholder image for case study 3" />
          <div class="case-card__body">
            <h3>Training + Project-Based Learning Model</h3>
            <p><strong>Problem:</strong> Learners lacking practical confidence.</p>
            <p><strong>Solution:</strong> Guided, project-oriented training structure.</p>
            <p><strong>Outcome:</strong> Better practical understanding and readiness.</p>
            <a class="text-link" href="#contact">Enquire About Training</a>
          </div>
        </article>
      </div>
    </div>
  </section>

  <!-- Testimonials -->
  <section class="section section--alt" id="testimonials">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Testimonials</p>
        <h2>What Clients & Learners Say (Placeholders)</h2>
        <p>Replace placeholders with your real testimonials and names.</p>
      </div>

      <div class="card-grid card-grid--3">
        <article class="quote-card">
          <p class="quote-card__text">“Placeholder testimonial about software delivery and support.”</p>
          <p class="quote-card__meta"><strong>Client Name</strong> • Business Owner</p>
        </article>
        <article class="quote-card">
          <p class="quote-card__text">“Placeholder testimonial about training clarity and confidence.”</p>
          <p class="quote-card__meta"><strong>Student Name</strong> • Java Full Stack</p>
        </article>
        <article class="quote-card">
          <p class="quote-card__text">“Placeholder testimonial about website quality and enquiries.”</p>
          <p class="quote-card__meta"><strong>Client Name</strong> • Services Business</p>
        </article>
      </div>
    </div>
  </section>

  <!-- FAQ Preview -->
  <section class="section" id="faq">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">FAQ</p>
        <h2>Frequently Asked Questions</h2>
        <p>These are homepage preview FAQs. A full FAQ page can be added later.</p>
      </div>

      <div class="faq-list">
        <details>
          <summary>What types of software solutions do you build?</summary>
          <p>We build custom web applications, business websites, Java-based solutions, and domain-specific software concepts based on requirements.</p>
        </details>

        <details>
          <summary>Can you build a custom solution for my workflow?</summary>
          <p>Yes. We first understand your process and then propose a practical solution approach, scope, and implementation plan.</p>
        </details>

        <details>
          <summary>Which course is best for beginners?</summary>
          <p>That depends on your goal. Core Java and Web Development are common starting points. Contact us and we’ll guide you.</p>
        </details>

        <details>
          <summary>Do you provide project-based training?</summary>
          <p>Yes. Our training approach is practical and project-oriented to improve real-world understanding and confidence.</p>
        </details>

        <details>
          <summary>How can I get course fees and batch details?</summary>
          <p>You can call, WhatsApp, or submit the enquiry form. We can share the latest batch schedule and fees.</p>
        </details>
      </div>
    </div>
  </section>

  <!-- Blog / Resources Preview -->
  <section class="section section--alt" id="resources">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Blog / Resources</p>
        <h2>Resources, Guides &amp; Updates</h2>
        <p>
          Helpful content for businesses, students, and professionals — from software planning to Java learning and digital growth tips.
        </p>
      </div>

      <div class="card-grid card-grid--3">
        <article class="resource-card">
          <span class="pill">Java Learning</span>
          <h3>How to Start Java Full Stack as a Beginner</h3>
          <p>Placeholder article preview text. Add your real blog posts later.</p>
          <a class="text-link" href="#">Read More</a>
        </article>

        <article class="resource-card">
          <span class="pill">Business Digitization</span>
          <h3>When Should a Small Business Build Custom Software?</h3>
          <p>Placeholder article preview text. Add your real blog posts later.</p>
          <a class="text-link" href="#">Read More</a>
        </article>

        <article class="resource-card">
          <span class="pill">Training & Careers</span>
          <h3>Project-Based Learning vs Theory-Only Learning</h3>
          <p>Placeholder article preview text. Add your real blog posts later.</p>
          <a class="text-link" href="#">Read More</a>
        </article>
      </div>
    </div>
  </section>

  <!-- Contact / Lead Capture -->
  <section class="section contact-section" id="contact">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Contact / Enquiry</p>
        <h2>Need a Software Solution or Want to Build Job-Ready Skills? Let’s Talk.</h2>
        <p>
          Whether you’re a business looking to digitize operations or a learner building a career in IT, Tawa Technology can help you move forward with a practical plan.
        </p>
      </div>

      <div class="contact-grid">
        <div class="contact-card">
          <h3>Contact Tawa Technology</h3>
          <ul class="contact-list">
            <li><strong>Phone:</strong> <a href="tel:+918799996171">+91 8799996171</a></li>
            <li><strong>WhatsApp:</strong> <a href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">Start WhatsApp Chat</a></li>
            <li><strong>Email:</strong> <a href="mailto:info@tawatechnology.com">info@tawatechnology.com</a></li>
            <li><strong>Location:</strong> Nagpur, India (Placeholder address)</li>
            <li><strong>Response Time:</strong> Within 72 hours)</li>
          </ul>

          <div class="contact-actions">
            <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">Call / WhatsApp Now</a>
            <a class="btn btn--secondary" href="tel:+918799996171">Call Now</a>
          </div>
        </div>

        <!-- Static-friendly form (Formspree/Netlify later) -->
        <form class="contact-form" action="#" method="post" novalidate>
          <h3>Send an Enquiry</h3>

          <div class="form-row">
            <label for="name">Full Name *</label>
            <input type="text" id="name" name="name" placeholder="Enter your full name" required />
          </div>

          <div class="form-row form-row--2">
            <div>
              <label for="email">Email *</label>
              <input type="email" id="email" name="email" placeholder="you@example.com" required />
            </div>
            <div>
              <label for="phone">Phone / WhatsApp *</label>
              <input type="tel" id="phone" name="phone" placeholder="+91 XXXXX XXXXX" required />
            </div>
          </div>

          <div class="form-row">
            <label for="inquiryType">Inquiry Type *</label>
            <select id="inquiryType" name="inquiryType" required>
              <option value="">Select inquiry type</option>
              <option value="software-project">Software Project</option>
              <option value="website-development">Website Development</option>
              <option value="product-demo">Product Demo</option>
              <option value="training-course">Training Course</option>
              <option value="corporate-training">Corporate / College Training</option>
              <option value="other">Other</option>
            </select>
          </div>

          <div class="form-row">
            <label for="message">Message *</label>
            <textarea id="message" name="message" rows="5" placeholder="Tell us your requirement or learning goal..." required></textarea>
          </div>

          <div class="form-row checkbox-row">
            <input type="checkbox" id="consent" name="consent" required />
            <label for="consent">I agree to be contacted by Tawa Technology regarding this enquiry.</label>
          </div>

          <button type="submit" class="btn btn--primary">Send Enquiry</button>
          <p class="form-note">
            Placeholder form setup. Later connect this to Formspree, Netlify Forms, or PHP mailer.
          </p>
        </form>
      </div>
    </div>
  </section>
</main>

<!-- Footer -->
  <!-- Footer -->
  <footer class="site-footer">
    <div class="container footer__grid">
      <div class="footer__col footer__col--brand">
        <a href="index.php" class="brand brand--footer">
          <img src="assets/img/logo.webp" alt="Tawa Technology logo" class="brand__logo" />
          <div class="brand__text">
            <span class="brand__name">Tawa Technology</span>
            <span class="brand__tagline">Empowering Businesses &amp; Students</span>
          </div>
        </a>

        <p class="footer__about">
          Tawa Technology helps businesses digitize operations through practical software solutions and helps students build job-ready skills through project-based IT training.
        </p>

        <div class="footer__quick-contact">
          <a href="tel:+918799996171">📞 +91 8799996171</a>
          <a href="mailto:info@tawatechnology.com">✉️ info@tawatechnology.com</a>
          <a href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">💬 WhatsApp Chat</a>
          <span>📍 Nagpur, India</span>
        </div>
      </div>

      <div class="footer__col">
        <h3>Software Solutions</h3>
        <ul>
          <li><a href="/software.php">Custom Web Applications</a></li>
          <li><a href="/software.php">Java / Enterprise Solutions</a></li>
          <li><a href="/software.php">Business Websites</a></li>
          <li><a href="/software.php">Process Digitization</a></li>
          <li><a href="/software.php">SEO & Digital Consulting</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Products</h3>
        <ul>
          <li><a href="products.php#advocate-diary">Advocate Diary</a></li>
          <li><a href="products.php#micro-finance">Micro Finance Management</a></li>
          <li><a href="products.php#custom-apps">Custom Business Apps</a></li>
          <li><a href="products.php">Product Demo Request</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Training & Courses</h3>
        <ul>
          <li><a href="training.php#java-full-stack">Java Full Stack</a></li>
          <li><a href="training.php#core-java">Core Java</a></li>
          <li><a href="training.php#sql-powerbi">SQL / Power BI</a></li>
          <li><a href="training.php#web-development">Web Development</a></li>
          <li><a href="training.php#fees">Course Fees</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Company</h3>
        <ul>
          <li><a href="about.php">About Tawa Technology</a></li>
          <li><a href="case-studies.php">Case Studies</a></li>
          <li><a href="blog.php">Resources / Blog</a></li>
          <li><a href="faq.php">FAQ</a></li>
          <li><a href="contact.php">Contact / Enquiry</a></li>
        </ul>
      </div>
    </div>

    <div class="container footer__bottom">
      <p>© <span id="year"></span> Tawa Technology. All rights reserved.</p>
      <div class="footer__links">
        <a href="privacy-policy.php">Privacy Policy</a>
        <a href="terms.php">Terms</a>
        <a href="contact.php">Contact</a>
      </div>
    </div>
  </footer>

  <!-- Mobile Sticky CTA Bar -->
  <div class="mobile-cta" role="region" aria-label="Quick contact actions">
    <a class="mobile-cta__btn" href="tel:+918799996171" aria-label="Call Tawa Technology">
      📞 Call
    </a>
    <a class="mobile-cta__btn mobile-cta__btn--whatsapp"
      href="https://wa.me/918799996171"
      target="_blank" rel="noopener noreferrer"
      aria-label="WhatsApp Tawa Technology">
      WhatsApp
    </a>
  </div>
  <script src="assets/js/main.js"></script>
  </body>

  </html></body>

</html>