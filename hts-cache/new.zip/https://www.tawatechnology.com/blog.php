<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Resources | Tawa Technology | Blog, Guides, Notes &amp; Templates</title>
  <meta name="description" content="Read practical resources by Tawa Technology: software and website guides, training notes, interview prep, SQL/Power BI tips, and business digitization insights." />
  <meta name="theme-color" content="#003399" />

  <!-- Open Graph (basic, reusable) -->
  <meta property="og:title" content="Resources | Tawa Technology | Blog, Guides, Notes &amp; Templates" />
  <meta property="og:description" content="Read practical resources by Tawa Technology: software and website guides, training notes, interview prep, SQL/Power BI tips, and business digitization insights." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://www.tawatechnology.com/" />
  <meta property="og:image" content="assets/img/hero-placeholder.jpg" />

  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Poppins:wght@600;700;800&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="assets/css/style.css" />
</head>
<body>
  <a class="skip-link" href="#main-content">Skip to content</a>

  <!-- Top Utility Bar -->
  <div class="topbar topbar--enhanced">
    <div class="container topbar__inner">
      <div class="topbar__left">
        <span class="topbar__item">📍 Nagpur, India</span>
        <a class="topbar__item" href="tel:+918799996171">📞 +91 8799996171</a>
        <a class="topbar__item" href="mailto:info@tawatechnology.com">✉️ info@tawatechnology.com</a>
      </div>
      <div class="topbar__right">
        <a class="topbar__pill" href="contact.php">Enquiry Form</a>
        <a class="topbar__pill topbar__pill--whatsapp" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">WhatsApp</a>
      </div>
    </div>
  </div>

  <!-- Main Header -->
  <header class="site-header" id="site-header">
    <div class="container header__inner">
      <a href="index.php" class="brand" aria-label="Tawa Technology home">
        <img src="assets/img/logo.webp" alt="Tawa Technology logo" class="brand__logo" />
        <div class="brand__text">
          <span class="brand__name">Tawa Technology</span>
          <span class="brand__tagline">Empowering Businesses &amp; Students</span>
        </div>
      </a>

      <button
        class="nav-toggle"
        id="navToggle"
        aria-expanded="false"
        aria-controls="primaryNav"
        aria-label="Open navigation menu"
      >
        <span></span>
        <span></span>
        <span></span>
      </button>

      <nav class="primary-nav" id="primaryNav" aria-label="Primary navigation">
        <ul class="menu">
          <li><a class="" href="index.php">Home</a></li>

          <li><a class="" href="software.php">Software Solutions</a></li>

          <!-- Dropdown-ready item -->
          <li class="has-dropdown">
            <button class="menu-btn " type="button" aria-expanded="false">
              Products
              <span class="caret" aria-hidden="true">▾</span>
            </button>
            <div class="dropdown" role="menu" aria-label="Products submenu">
              <a href="products.php">All Products</a>
              <a href="products.php#advocate-diary">Advocate Diary</a>
              <a href="products.php#micro-finance">Micro Finance</a>
              <a href="products.php#custom-apps">Custom Business Apps</a>
            </div>
          </li>

          <li class="has-dropdown">
            <button class="menu-btn " type="button" aria-expanded="false">
              Training
              <span class="caret" aria-hidden="true">▾</span>
            </button>
            <div class="dropdown" role="menu" aria-label="Training submenu">
              <a href="training.php">All Courses</a>
              <a href="training.php#java-full-stack">Java Full Stack</a>
              <a href="training.php#core-java">Core Java</a>
              <a href="training.php#sql-powerbi">SQL / Power BI</a>
              <a href="training.php#web-development">Web Development</a>
            </div>
          </li>

          <li><a class="" href="case-studies.php">Case Studies</a></li>
          <li><a class="" href="about.php">About</a></li>
          <li><a class="is-active" href="blog.php">Resources</a></li>
          <li><a class="" href="contact.php">Contact</a></li>
        </ul>

        <div class="nav-cta nav-cta--desktop">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">
            Call / WhatsApp Now
          </a>
        </div>
      </nav>
    </div>
  </header>
<main id="main-content">
  <!-- Hero -->
  <section class="section hero hero--inner">
    <div class="container hero__grid">
      <div class="hero__content">
        <p class="eyebrow">Resources / Blog</p>
        <h1>Practical Guides for Businesses & Learners</h1>
        <p class="hero__lead">
          Short, practical resources from Tawa Technology covering software, websites, digitization, and job-ready IT learning
          (Java, SQL, Power BI, Web Development). Use these as quick references and implementation guides.
        </p>

        <div class="hero__actions">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">
            Call / WhatsApp Now
          </a>
          <a class="btn btn--secondary" href="#latest">Explore Resources</a>
        </div>

        <ul class="hero__trust">
          <li>Clear and actionable</li>
          <li>Business + training aligned</li>
          <li>SEO-friendly content hub</li>
        </ul>
      </div>

      <div class="hero__visual">
        <img src="assets/img/Practical_Guides_Businesses_Learners.webp" alt="Learning resources and software guides" />
      </div>
    </div>
  </section>

  <!-- Search + Categories -->
  <section class="section section--alt" id="browse">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Browse</p>
        <h2>Search and Filter Resources</h2>
        <p>
          This search is front-end only (no backend). You can later connect it to a CMS or static generator if you want.
        </p>
      </div>

      <div class="resource-toolbar">
        <div class="resource-search" role="search">
          <label class="sr-only" for="resourceSearch">Search resources</label>
          <input id="resourceSearch" type="search" placeholder="Search: Java, SQL, website, micro finance, SEO..." />
          <button class="btn btn--secondary btn--sm" id="clearSearch" type="button">Clear</button>
        </div>

        <div class="chip-row" aria-label="Resource categories">
          <button class="chip is-active" type="button" data-filter="all">All</button>
          <button class="chip" type="button" data-filter="business">For Businesses</button>
          <button class="chip" type="button" data-filter="training">For Students</button>
          <button class="chip" type="button" data-filter="java">Java</button>
          <button class="chip" type="button" data-filter="sql">SQL / Power BI</button>
          <button class="chip" type="button" data-filter="web">Web Development</button>
          <button class="chip" type="button" data-filter="seo">SEO / Digital</button>
        </div>
      </div>
    </div>
  </section>

  <!-- Featured Resources -->
  <section class="section" id="featured">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Featured</p>
        <h2>Top Resources</h2>
        <p>Guides, PDFs, notes, checklists, or popular blog posts.</p>
      </div>

      <div class="card-grid card-grid--3">
        <article class="resource-card" data-tags="business web">
          <span class="pill">For Businesses</span>
          <h3>How to Plan a Business Website That Generates Leads</h3>
          <p class="muted">5–7 min read • Website strategy</p>
          <p>Clear structure: messaging, service pages, CTAs, contact flow, and SEO basics.</p>
          <div class="card-actions">
            <a class="btn btn--secondary btn--sm" href="blog-how-to-plan-a-business-website.php">Read</a>
            <a class="text-link" href="contact.php">Need a Website?</a>
          </div>
        </article>

        <article class="resource-card" data-tags="training java">
          <span class="pill">Java</span>
          <h3>Core Java Learning Path: Beginner to Job-Ready</h3>
          <p class="muted">8–10 min read • Training</p>
          <p>A structured path covering fundamentals, OOP, collections, exceptions, and practice ideas.</p>
          <div class="card-actions">
            <a class="btn btn--secondary btn--sm" href="blog-core-java-learning-path.php">Read</a>
            <a class="text-link" href="training.php">Join Training</a>
          </div>
        </article>

        <article class="resource-card" data-tags="training sql">
          <span class="pill">SQL / Power BI</span>
          <h3>SQL for Reporting: Queries Every Analyst Must Know</h3>
          <p class="muted">6–9 min read • SQL</p>
          <p>Joins, aggregates, date logic, performance basics, and real-world report patterns.</p>
          <div class="card-actions">
            <a class="btn btn--secondary btn--sm" href="#">Read</a>
            <a class="text-link" href="training.php#sql-powerbi">Course Details</a>
          </div>
        </article>
      </div>
    </div>
  </section>

  <!-- Latest Posts Grid -->
  <section class="section section--alt" id="latest">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Latest</p>
        <h2>Latest Articles</h2>
      </div>

      <div class="blog-grid" id="blogGrid">
        <!-- Post cards (placeholders) -->
        <article class="post-card" data-tags="business digitization">
          <img src="assets/img/Digitization_Checklist_Small_Businesses.webp" alt="business digitization" />
          <div class="post-card__body">
            <span class="pill">For Businesses</span>
            <h3><a href="#">Digitization Checklist for Small Businesses</a></h3>
            <p class="muted">Category: Business • Read: 5 min</p>
            <p>Simple checklist to move from manual tracking to digital workflows step-by-step.</p>
            <div class="card-actions">
              <a class="text-link" href="software.php#process">How We Work</a>
              <a class="text-link" href="contact.php">Discuss Now</a>
            </div>
          </div>
        </article>

        <article class="post-card" data-tags="web seo">
          <img src="assets/img/SEOBasicsforServiceBusinesses.webp" alt="Placeholder blog image: SEO basics" />
          <div class="post-card__body">
            <span class="pill">SEO / Digital</span>
            <h3><a href="#">On-Page SEO Basics for Service Businesses</a></h3>
            <p class="muted">Category: SEO • Read: 6 min</p>
            <p>Titles, headings, internal links, and content blocks that improve local search visibility.</p>
            <div class="card-actions">
              <a class="text-link" href="software.php#software-services">SEO Services</a>
              <a class="text-link" href="contact.php">Get Help</a>
            </div>
          </div>
        </article>

        <article class="post-card" data-tags="training java">
          <img src="assets/img/OOPConceptsExplained.webp" alt="Placeholder blog image: Java OOP concepts" />
          <div class="post-card__body">
            <span class="pill">Java</span>
            <h3><a href="#">OOP Concepts Explained with Simple Examples</a></h3>
            <p class="muted">Category: Training • Read: 7 min</p>
            <p>Inheritance, polymorphism, abstraction, and encapsulation—explained simply.</p>
            <div class="card-actions">
              <a class="text-link" href="training.php#core-java">Core Java</a>
              <a class="text-link" href="contact.php">Enquire</a>
            </div>
          </div>
        </article>

        <article class="post-card" data-tags="training sql">
          <img src="assets/img/SQL_Joins_Practical_Guide.webp" alt="Placeholder blog image: SQL joins" />
          <div class="post-card__body">
            <span class="pill">SQL / Power BI</span>
            <h3><a href="#">SQL Joins: A Practical Guide for Beginners</a></h3>
            <p class="muted">Category: SQL • Read: 6 min</p>
            <p>INNER, LEFT, RIGHT, FULL joins with real-world reporting examples (placeholder).</p>
            <div class="card-actions">
              <a class="text-link" href="training.php#sql-powerbi">SQL Course</a>
              <a class="text-link" href="contact.php">Ask on WhatsApp</a>
            </div>
          </div>
        </article>

        <article class="post-card" data-tags="training web">
          <img src="assets/img/ResponsiveWebsiteLayoutBasics.webp" alt="Placeholder blog image: responsive web design" />
          <div class="post-card__body">
            <span class="pill">Web Development</span>
            <h3><a href="#">Responsive Website Layout Basics</a></h3>
            <p class="muted">Category: Web Dev • Read: 5 min</p>
            <p>Mobile-first layout, grid systems, spacing, and best practices for clean UI.</p>
            <div class="card-actions">
              <a class="text-link" href="training.php#web-development">Web Dev Course</a>
              <a class="text-link" href="contact.php">Enquire</a>
            </div>
          </div>
        </article>

        <article class="post-card" data-tags="business products">
          <img src="assets/img/ProductvsCustomSoftware.webp" alt="Placeholder blog image: product demo" />
          <div class="post-card__body">
            <span class="pill">Products</span>
            <h3><a href="#">When to Choose a Product vs Custom Software</a></h3>
            <p class="muted">Category: Business • Read: 5 min</p>
            <p>How to decide between adopting a base product and building a custom system.</p>
            <div class="card-actions">
              <a class="text-link" href="products.php">Explore Products</a>
              <a class="text-link" href="contact.php">Discuss</a>
            </div>
          </div>
        </article>
      </div>

      <div class="cta-inline">
        <a class="btn btn--secondary" href="contact.php">Ask a Question</a>
        <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">WhatsApp Now</a>
      </div>
    </div>
  </section>

  <!-- Lead Magnet / CTA -->
  <section class="section" id="lead-magnet">
    <div class="container">
      <div class="cta-banner">
        <div class="cta-banner__content">
          <p class="eyebrow">Free Resource (Placeholder)</p>
          <h2>Want Notes, Templates, or a Course Plan PDF?</h2>
          <p>
            Tell us what you need on WhatsApp and we’ll share the right resource (or guide you to the best starting point).
          </p>
        </div>
        <div class="cta-banner__actions">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">Request on WhatsApp</a>
          <a class="btn btn--secondary" href="training.php">Explore Courses</a>
        </div>
      </div>
    </div>
  </section>

  <!-- FAQ -->
  <section class="section section--alt" id="blog-faq">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Resources FAQ</p>
        <h2>Frequently Asked Questions</h2>
      </div>

      <div class="faq-list">
        <details>
          <summary>Do you provide PDFs / notes for courses?</summary>
          <p>Yes (placeholder). We can share structured notes and guidance based on your course and level.</p>
        </details>

        <details>
          <summary>Can I request a topic you should write about?</summary>
          <p>Yes. Send the topic on WhatsApp and we’ll plan it as a resource (placeholder).</p>
        </details>

        <details>
          <summary>Do these resources support both businesses and students?</summary>
          <p>Yes. We publish content for software/website decisions and for learning/job preparation.</p>
        </details>
      </div>
    </div>
  </section>
</main>

<script>
  (function() {
    const searchInput = document.getElementById("resourceSearch");
    const clearBtn = document.getElementById("clearSearch");
    const chips = Array.from(document.querySelectorAll(".chip-row .chip"));
    const cards = Array.from(document.querySelectorAll("#blogGrid .post-card"));
    let activeFilter = "all";

    function normalize(s) {
      return (s || "").toLowerCase().trim();
    }

    function applyFilter() {
      const q = normalize(searchInput.value);
      cards.forEach(card => {
        const tags = normalize(card.getAttribute("data-tags"));
        const text = normalize(card.innerText);
        const matchQuery = !q || text.includes(q) || tags.includes(q);
        const matchFilter = activeFilter === "all" || tags.includes(activeFilter);
        card.style.display = (matchQuery && matchFilter) ? "" : "none";
      });
    }

    chips.forEach(chip => {
      chip.addEventListener("click", () => {
        chips.forEach(c => c.classList.remove("is-active"));
        chip.classList.add("is-active");
        activeFilter = chip.getAttribute("data-filter") || "all";
        applyFilter();
      });
    });

    searchInput.addEventListener("input", applyFilter);
    clearBtn.addEventListener("click", () => {
      searchInput.value = "";
      applyFilter();
    });

    applyFilter();
  })();
</script>

  <!-- Footer -->
  <footer class="site-footer">
    <div class="container footer__grid">
      <div class="footer__col footer__col--brand">
        <a href="index.php" class="brand brand--footer">
          <img src="assets/img/logo.webp" alt="Tawa Technology logo" class="brand__logo" />
          <div class="brand__text">
            <span class="brand__name">Tawa Technology</span>
            <span class="brand__tagline">Empowering Businesses &amp; Students</span>
          </div>
        </a>

        <p class="footer__about">
          Tawa Technology helps businesses digitize operations through practical software solutions and helps students build job-ready skills through project-based IT training.
        </p>

        <div class="footer__quick-contact">
          <a href="tel:+918799996171">📞 +91 8799996171</a>
          <a href="mailto:info@tawatechnology.com">✉️ info@tawatechnology.com</a>
          <a href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">💬 WhatsApp Chat</a>
          <span>📍 Nagpur, India</span>
        </div>
      </div>

      <div class="footer__col">
        <h3>Software Solutions</h3>
        <ul>
          <li><a href="/software.php">Custom Web Applications</a></li>
          <li><a href="/software.php">Java / Enterprise Solutions</a></li>
          <li><a href="/software.php">Business Websites</a></li>
          <li><a href="/software.php">Process Digitization</a></li>
          <li><a href="/software.php">SEO & Digital Consulting</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Products</h3>
        <ul>
          <li><a href="products.php#advocate-diary">Advocate Diary</a></li>
          <li><a href="products.php#micro-finance">Micro Finance Management</a></li>
          <li><a href="products.php#custom-apps">Custom Business Apps</a></li>
          <li><a href="products.php">Product Demo Request</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Training & Courses</h3>
        <ul>
          <li><a href="training.php#java-full-stack">Java Full Stack</a></li>
          <li><a href="training.php#core-java">Core Java</a></li>
          <li><a href="training.php#sql-powerbi">SQL / Power BI</a></li>
          <li><a href="training.php#web-development">Web Development</a></li>
          <li><a href="training.php#fees">Course Fees</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Company</h3>
        <ul>
          <li><a href="about.php">About Tawa Technology</a></li>
          <li><a href="case-studies.php">Case Studies</a></li>
          <li><a href="blog.php">Resources / Blog</a></li>
          <li><a href="faq.php">FAQ</a></li>
          <li><a href="contact.php">Contact / Enquiry</a></li>
        </ul>
      </div>
    </div>

    <div class="container footer__bottom">
      <p>© <span id="year"></span> Tawa Technology. All rights reserved.</p>
      <div class="footer__links">
        <a href="privacy-policy.php">Privacy Policy</a>
        <a href="terms.php">Terms</a>
        <a href="contact.php">Contact</a>
      </div>
    </div>
  </footer>

  <!-- Mobile Sticky CTA Bar -->
  <div class="mobile-cta" role="region" aria-label="Quick contact actions">
    <a class="mobile-cta__btn" href="tel:+918799996171" aria-label="Call Tawa Technology">
      📞 Call
    </a>
    <a class="mobile-cta__btn mobile-cta__btn--whatsapp"
      href="https://wa.me/918799996171"
      target="_blank" rel="noopener noreferrer"
      aria-label="WhatsApp Tawa Technology">
      WhatsApp
    </a>
  </div>
  <script src="assets/js/main.js"></script>
  </body>

  </html>