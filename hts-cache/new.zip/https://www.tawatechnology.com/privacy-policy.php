<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Privacy Policy | Tawa Technology</title>
  <meta name="description" content="Privacy Policy for Tawa Technology. Learn how we collect, use, and protect your information when you use our website, services, and training programs." />
  <meta name="theme-color" content="#003399" />

  <!-- Open Graph (basic, reusable) -->
  <meta property="og:title" content="Privacy Policy | Tawa Technology" />
  <meta property="og:description" content="Privacy Policy for Tawa Technology. Learn how we collect, use, and protect your information when you use our website, services, and training programs." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://www.tawatechnology.com/" />
  <meta property="og:image" content="assets/img/hero-placeholder.jpg" />

  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Poppins:wght@600;700;800&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="assets/css/style.css" />
</head>
<body>
  <a class="skip-link" href="#main-content">Skip to content</a>

  <!-- Top Utility Bar -->
  <div class="topbar topbar--enhanced">
    <div class="container topbar__inner">
      <div class="topbar__left">
        <span class="topbar__item">📍 Nagpur, India</span>
        <a class="topbar__item" href="tel:+918799996171">📞 +91 8799996171</a>
        <a class="topbar__item" href="mailto:info@tawatechnology.com">✉️ info@tawatechnology.com</a>
      </div>
      <div class="topbar__right">
        <a class="topbar__pill" href="contact.php">Enquiry Form</a>
        <a class="topbar__pill topbar__pill--whatsapp" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">WhatsApp</a>
      </div>
    </div>
  </div>

  <!-- Main Header -->
  <header class="site-header" id="site-header">
    <div class="container header__inner">
      <a href="index.php" class="brand" aria-label="Tawa Technology home">
        <img src="assets/img/logo.webp" alt="Tawa Technology logo" class="brand__logo" />
        <div class="brand__text">
          <span class="brand__name">Tawa Technology</span>
          <span class="brand__tagline">Empowering Businesses &amp; Students</span>
        </div>
      </a>

      <button
        class="nav-toggle"
        id="navToggle"
        aria-expanded="false"
        aria-controls="primaryNav"
        aria-label="Open navigation menu"
      >
        <span></span>
        <span></span>
        <span></span>
      </button>

      <nav class="primary-nav" id="primaryNav" aria-label="Primary navigation">
        <ul class="menu">
          <li><a class="" href="index.php">Home</a></li>

          <li><a class="" href="software.php">Software Solutions</a></li>

          <!-- Dropdown-ready item -->
          <li class="has-dropdown">
            <button class="menu-btn " type="button" aria-expanded="false">
              Products
              <span class="caret" aria-hidden="true">▾</span>
            </button>
            <div class="dropdown" role="menu" aria-label="Products submenu">
              <a href="products.php">All Products</a>
              <a href="products.php#advocate-diary">Advocate Diary</a>
              <a href="products.php#micro-finance">Micro Finance</a>
              <a href="products.php#custom-apps">Custom Business Apps</a>
            </div>
          </li>

          <li class="has-dropdown">
            <button class="menu-btn " type="button" aria-expanded="false">
              Training
              <span class="caret" aria-hidden="true">▾</span>
            </button>
            <div class="dropdown" role="menu" aria-label="Training submenu">
              <a href="training.php">All Courses</a>
              <a href="training.php#java-full-stack">Java Full Stack</a>
              <a href="training.php#core-java">Core Java</a>
              <a href="training.php#sql-powerbi">SQL / Power BI</a>
              <a href="training.php#web-development">Web Development</a>
            </div>
          </li>

          <li><a class="" href="case-studies.php">Case Studies</a></li>
          <li><a class="" href="about.php">About</a></li>
          <li><a class="" href="blog.php">Resources</a></li>
          <li><a class="" href="contact.php">Contact</a></li>
        </ul>

        <div class="nav-cta nav-cta--desktop">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">
            Call / WhatsApp Now
          </a>
        </div>
      </nav>
    </div>
  </header>
<main id="main-content">
  <!-- Hero / Header -->
  <section class="section hero hero--inner">
    <div class="container hero__grid">
      <div class="hero__content">
        <p class="eyebrow">Legal</p>
        <h1>Privacy Policy</h1>
        <p class="hero__lead">
          This Privacy Policy explains how Tawa Technology (“we”, “us”, “our”) collects, uses, and protects your
          personal information when you visit our website or contact us for software services or training programs.
        </p>
        <div class="hero__actions">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">
            Call / WhatsApp Now
          </a>
          <a class="btn btn--secondary" href="contact.php">Contact</a>
        </div>
        <p class="muted" style="margin-top:10px;">
          Effective Date: <strong>[DD Month YYYY]</strong> • Last Updated: <strong>[DD Month YYYY]</strong>
        </p>
      </div>

      <div class="hero__visual">
        <img src="assets/img/legal-placeholder.jpg" alt="Privacy policy and data protection" />
      </div>
    </div>
  </section>

  <!-- Content -->
  <section class="section">
    <div class="container content-page">

      <div class="notice-box">
        <strong>Important:</strong>
        This page is a general website privacy policy template for Tawa Technology.
        Replace placeholders with your final business/legal details as needed.
      </div>

      <h2>1) Who We Are</h2>
      <p>
        <strong>Tawa Technology</strong> is based in Nagpur, India and provides:
      </p>
      <ul>
        <li>Software Development & IT Solutions (custom web apps, enterprise Java applications, domain products)</li>
        <li>Training & Education (Java Full Stack, Core Java, SQL/Power BI, Web Development)</li>
        <li>Digital & Web Services (website development, SEO, digital consulting)</li>
      </ul>

      <h2>2) Information We Collect</h2>
      <p>We may collect the following types of information:</p>
      <ul>
        <li><strong>Contact details:</strong> name, phone number, email address (when you submit a form or message us).</li>
        <li><strong>Inquiry details:</strong> your message, project requirements, course interest, preferred timing.</li>
        <li><strong>Technical data:</strong> IP address, browser/device type, approximate location, pages visited.</li>
        <li><strong>Training data (if applicable):</strong> enrollment details, attendance notes (placeholder), feedback.</li>
      </ul>

      <h2>3) How We Collect Information</h2>
      <ul>
        <li>When you fill out our enquiry/contact forms.</li>
        <li>When you contact us via phone, WhatsApp, email, or social channels.</li>
        <li>Through cookies/analytics tools (if enabled on the website).</li>
      </ul>

      <h2>4) How We Use Your Information</h2>
      <p>We use your information to:</p>
      <ul>
        <li>Respond to enquiries and provide quotations or consultation.</li>
        <li>Provide training information, schedules, and enrollment assistance.</li>
        <li>Improve website experience, content, and services.</li>
        <li>Send important updates related to your enquiry (no spam).</li>
        <li>Maintain basic security and prevent abuse.</li>
      </ul>

      <h2>5) Cookies & Analytics</h2>
      <p>
        We may use cookies to improve the website experience. Cookies are small files stored in your browser.
        If we use analytics tools (e.g., Google Analytics), they may collect anonymized usage data such as pages visited and time spent.
      </p>
      <p>
        You can disable cookies in your browser settings, but some site features may not function properly.
      </p>

      <h2>6) Sharing of Information</h2>
      <p>
        We do <strong>not</strong> sell your personal data. We may share your information only in limited cases:
      </p>
      <ul>
        <li><strong>Service providers:</strong> email delivery, hosting, form processing tools (as required to operate the site).</li>
        <li><strong>Legal requirements:</strong> if required by law or to protect our rights and users.</li>
        <li><strong>Business execution:</strong> if needed to deliver a requested service (e.g., third-party integrations) with your consent.</li>
      </ul>

      <h2>7) Data Security</h2>
      <p>
        We take reasonable measures to protect your information from unauthorized access, misuse, or disclosure.
        However, no internet transmission is 100% secure. Please share sensitive information only when necessary.
      </p>

      <h2>8) Data Retention</h2>
      <p>
        We keep your data only as long as needed for enquiry handling, service delivery, compliance, and legitimate business purposes.
        (Retention periods can be updated based on your policy.)
      </p>

      <h2>9) Your Rights & Choices</h2>
      <p>You can request the following by contacting us:</p>
      <ul>
        <li>Access to the personal data we hold about you (subject to verification).</li>
        <li>Correction of inaccurate data.</li>
        <li>Deletion of your data (where legally permitted).</li>
        <li>Opt-out of non-essential communications.</li>
      </ul>

      <h2>10) Third-Party Links</h2>
      <p>
        Our website may contain links to third-party sites (example: product login or external platforms).
        We are not responsible for the privacy practices of external websites. Please review their policies separately.
      </p>

      <h2>11) Children’s Privacy</h2>
      <p>
        Our services are intended for students and professionals. If a minor submits data, it should be with parental/guardian consent.
        (Update this section as per your training policy.)
      </p>

      <h2>12) Changes to This Privacy Policy</h2>
      <p>
        We may update this policy from time to time. The updated version will be posted on this page with the revised date.
      </p>

      <h2>13) Contact Us</h2>
      <p>If you have questions about this Privacy Policy, contact:</p>
      <ul>
        <li><strong>Email:</strong> <a href="mailto:info@tawatechnology.com">info@tawatechnology.com</a></li>
        <li><strong>Phone:</strong> <a href="tel:+918799996171">+91 8799996171</a></li>
        <li><strong>WhatsApp:</strong> <a href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">Chat on WhatsApp</a></li>
        <li><strong>Location:</strong> Nagpur, India (placeholder full address)</li>
      </ul>

      <div class="cta-banner" style="margin-top:24px;">
        <div class="cta-banner__content">
          <p class="eyebrow">Need Help?</p>
          <h2>Talk to us about your project or training requirements</h2>
          <p>We respond fastest on WhatsApp.</p>
        </div>
        <div class="cta-banner__actions">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">WhatsApp Now</a>
          <a class="btn btn--secondary" href="contact.php">Contact Form</a>
        </div>
      </div>

    </div>
  </section>
</main>

  <!-- Footer -->
  <footer class="site-footer">
    <div class="container footer__grid">
      <div class="footer__col footer__col--brand">
        <a href="index.php" class="brand brand--footer">
          <img src="assets/img/logo.webp" alt="Tawa Technology logo" class="brand__logo" />
          <div class="brand__text">
            <span class="brand__name">Tawa Technology</span>
            <span class="brand__tagline">Empowering Businesses &amp; Students</span>
          </div>
        </a>

        <p class="footer__about">
          Tawa Technology helps businesses digitize operations through practical software solutions and helps students build job-ready skills through project-based IT training.
        </p>

        <div class="footer__quick-contact">
          <a href="tel:+918799996171">📞 +91 8799996171</a>
          <a href="mailto:info@tawatechnology.com">✉️ info@tawatechnology.com</a>
          <a href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">💬 WhatsApp Chat</a>
          <span>📍 Nagpur, India</span>
        </div>
      </div>

      <div class="footer__col">
        <h3>Software Solutions</h3>
        <ul>
          <li><a href="/software.php">Custom Web Applications</a></li>
          <li><a href="/software.php">Java / Enterprise Solutions</a></li>
          <li><a href="/software.php">Business Websites</a></li>
          <li><a href="/software.php">Process Digitization</a></li>
          <li><a href="/software.php">SEO & Digital Consulting</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Products</h3>
        <ul>
          <li><a href="products.php#advocate-diary">Advocate Diary</a></li>
          <li><a href="products.php#micro-finance">Micro Finance Management</a></li>
          <li><a href="products.php#custom-apps">Custom Business Apps</a></li>
          <li><a href="products.php">Product Demo Request</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Training & Courses</h3>
        <ul>
          <li><a href="training.php#java-full-stack">Java Full Stack</a></li>
          <li><a href="training.php#core-java">Core Java</a></li>
          <li><a href="training.php#sql-powerbi">SQL / Power BI</a></li>
          <li><a href="training.php#web-development">Web Development</a></li>
          <li><a href="training.php#fees">Course Fees</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Company</h3>
        <ul>
          <li><a href="about.php">About Tawa Technology</a></li>
          <li><a href="case-studies.php">Case Studies</a></li>
          <li><a href="blog.php">Resources / Blog</a></li>
          <li><a href="faq.php">FAQ</a></li>
          <li><a href="contact.php">Contact / Enquiry</a></li>
        </ul>
      </div>
    </div>

    <div class="container footer__bottom">
      <p>© <span id="year"></span> Tawa Technology. All rights reserved.</p>
      <div class="footer__links">
        <a href="privacy-policy.php">Privacy Policy</a>
        <a href="terms.php">Terms</a>
        <a href="contact.php">Contact</a>
      </div>
    </div>
  </footer>

  <!-- Mobile Sticky CTA Bar -->
  <div class="mobile-cta" role="region" aria-label="Quick contact actions">
    <a class="mobile-cta__btn" href="tel:+918799996171" aria-label="Call Tawa Technology">
      📞 Call
    </a>
    <a class="mobile-cta__btn mobile-cta__btn--whatsapp"
      href="https://wa.me/918799996171"
      target="_blank" rel="noopener noreferrer"
      aria-label="WhatsApp Tawa Technology">
      WhatsApp
    </a>
  </div>
  <script src="assets/js/main.js"></script>
  </body>

  </html>