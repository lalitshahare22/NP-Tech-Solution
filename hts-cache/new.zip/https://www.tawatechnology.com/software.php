s<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Software Solutions | Tawa Technology | Custom Web Apps, Business Websites &amp; IT Solutions</title>
  <meta name="description" content="Tawa Technology provides custom web applications, Java/enterprise solutions, business websites, process digitization, and digital consulting for small and medium businesses in Nagpur." />
  <meta name="theme-color" content="#003399" />

  <!-- Open Graph (basic, reusable) -->
  <meta property="og:title" content="Software Solutions | Tawa Technology | Custom Web Apps, Business Websites &amp; IT Solutions" />
  <meta property="og:description" content="Tawa Technology provides custom web applications, Java/enterprise solutions, business websites, process digitization, and digital consulting for small and medium businesses in Nagpur." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://www.tawatechnology.com/" />
  <meta property="og:image" content="assets/img/hero-placeholder.jpg" />

  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Poppins:wght@600;700;800&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="assets/css/style.css" />
</head>
<body>
  <a class="skip-link" href="#main-content">Skip to content</a>

  <!-- Top Utility Bar -->
  <div class="topbar topbar--enhanced">
    <div class="container topbar__inner">
      <div class="topbar__left">
        <span class="topbar__item">📍 Nagpur, India</span>
        <a class="topbar__item" href="tel:+918799996171">📞 +91 8799996171</a>
        <a class="topbar__item" href="mailto:info@tawatechnology.com">✉️ info@tawatechnology.com</a>
      </div>
      <div class="topbar__right">
        <a class="topbar__pill" href="contact.php">Enquiry Form</a>
        <a class="topbar__pill topbar__pill--whatsapp" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">WhatsApp</a>
      </div>
    </div>
  </div>

  <!-- Main Header -->
  <header class="site-header" id="site-header">
    <div class="container header__inner">
      <a href="index.php" class="brand" aria-label="Tawa Technology home">
        <img src="assets/img/logo.webp" alt="Tawa Technology logo" class="brand__logo" />
        <div class="brand__text">
          <span class="brand__name">Tawa Technology</span>
          <span class="brand__tagline">Empowering Businesses &amp; Students</span>
        </div>
      </a>

      <button
        class="nav-toggle"
        id="navToggle"
        aria-expanded="false"
        aria-controls="primaryNav"
        aria-label="Open navigation menu"
      >
        <span></span>
        <span></span>
        <span></span>
      </button>

      <nav class="primary-nav" id="primaryNav" aria-label="Primary navigation">
        <ul class="menu">
          <li><a class="" href="index.php">Home</a></li>

          <li><a class="is-active" href="software.php">Software Solutions</a></li>

          <!-- Dropdown-ready item -->
          <li class="has-dropdown">
            <button class="menu-btn " type="button" aria-expanded="false">
              Products
              <span class="caret" aria-hidden="true">▾</span>
            </button>
            <div class="dropdown" role="menu" aria-label="Products submenu">
              <a href="products.php">All Products</a>
              <a href="products.php#advocate-diary">Advocate Diary</a>
              <a href="products.php#micro-finance">Micro Finance</a>
              <a href="products.php#custom-apps">Custom Business Apps</a>
            </div>
          </li>

          <li class="has-dropdown">
            <button class="menu-btn " type="button" aria-expanded="false">
              Training
              <span class="caret" aria-hidden="true">▾</span>
            </button>
            <div class="dropdown" role="menu" aria-label="Training submenu">
              <a href="training.php">All Courses</a>
              <a href="training.php#java-full-stack">Java Full Stack</a>
              <a href="training.php#core-java">Core Java</a>
              <a href="training.php#sql-powerbi">SQL / Power BI</a>
              <a href="training.php#web-development">Web Development</a>
            </div>
          </li>

          <li><a class="" href="case-studies.php">Case Studies</a></li>
          <li><a class="" href="about.php">About</a></li>
          <li><a class="" href="blog.php">Resources</a></li>
          <li><a class="" href="contact.php">Contact</a></li>
        </ul>

        <div class="nav-cta nav-cta--desktop">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">
            Call / WhatsApp Now
          </a>
        </div>
      </nav>
    </div>
  </header>
<main id="main-content">
  <!-- Hero -->
  <section class="section hero hero--inner">
    <div class="container hero__grid">
      <div class="hero__content">
        <p class="eyebrow">Software Solutions for Businesses</p>
        <h1>Practical Software & Digital Solutions for Small and Medium Businesses</h1>
        <p class="hero__lead">
          Tawa Technology helps businesses reduce manual work, improve process visibility, and build reliable digital systems —
          from business websites to custom web applications and domain-specific solutions.
        </p>

        <div class="hero__actions">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">
            Call / WhatsApp Now
          </a>
          <a class="btn btn--secondary" href="/contact.php">Talk to an Expert</a>
        </div>

        <ul class="hero__trust">
          <li>Requirement-first approach</li>
          <li>Business workflow-oriented solutions</li>
          <li>SMB-friendly execution and support</li>
        </ul>
      </div>

      <div class="hero__visual">
        <img src="assets/img/PracticalSoftwareDigitalSolutions.webp" alt="Placeholder image for custom software development and business digitization" />
      </div>
    </div>
  </section>

  <!-- Quick Business CTA Strip -->
  <section class="section section--alt section--compact">
    <div class="container">
      <div class="cta-banner">
        <div class="cta-banner__content">
          <p class="eyebrow">Start With a Discussion</p>
          <h2>Need Software, a Business Website, or Process Digitization?</h2>
          <p>
            Share your requirement in a quick call or WhatsApp message. We’ll help you define a practical next step.
          </p>
        </div>
        <div class="cta-banner__actions">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">WhatsApp Now</a>
          <a class="btn btn--secondary" href="tel:+918799996171">Call +91 8799996171</a>
        </div>
      </div>
    </div>
  </section>

  <!-- Problems We Solve -->
  <section class="section">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Business Challenges We Solve</p>
        <h2>We Focus on Real Operational Problems — Not Just Features</h2>
        <p>
          Many businesses already know they need digitization, but not the right solution structure. We help identify
          the problem clearly and build a solution that fits your workflow, team, and budget.
        </p>
      </div>

      <div class="card-grid card-grid--3">
        <article class="feature-card">
          <h3>Manual Record Keeping</h3>
          <p>
            Replace notebooks, scattered files, and repetitive data entry with organized digital workflows and structured records.
          </p>
        </article>

        <article class="feature-card">
          <h3>Lack of Reporting Visibility</h3>
          <p>
            Build systems that help you view data, track activities, and generate useful reports for decision-making.
          </p>
        </article>

        <article class="feature-card">
          <h3>Disconnected Processes</h3>
          <p>
            Integrate core tasks and reduce dependency on ad-hoc communication or manual follow-ups.
          </p>
        </article>

        <article class="feature-card">
          <h3>Low Credibility Online</h3>
          <p>
            Improve your digital presence with a professional website that clearly explains your services and collects enquiries.
          </p>
        </article>

        <article class="feature-card">
          <h3>Generic Tools That Don’t Fit</h3>
          <p>
            Get customized solutions designed around your actual process, roles, and domain requirements.
          </p>
        </article>

        <article class="feature-card">
          <h3>Growth Without Systems</h3>
          <p>
            Create a stronger technology foundation before operations become harder to manage at a larger scale.
          </p>
        </article>
      </div>
    </div>
  </section>

  <!-- Service Categories -->
  <section class="section section--alt" id="software-services">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Service Categories</p>
        <h2>Software & Digital Services We Offer</h2>
        <p>
          We offer a practical mix of custom development, web presence solutions, and consulting support to help businesses grow.
        </p>
      </div>

      <div class="card-grid card-grid--2">
        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">🧩</div>
          <h3>Custom Web Applications</h3>
          <p>
            Build tailored applications for your operations, records, workflows, and internal process management.
          </p>
          <ul class="list-check">
            <li>Requirement-based feature planning</li>
            <li>Role-based workflows (admin/staff/users)</li>
            <li>Data entry + search + tracking modules</li>
            <li>Report-friendly design structure</li>
          </ul>
          <a class="text-link" href="contact.php">Discuss a Custom Application</a>
        </article>

        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">⚙️</div>
          <h3>Java / Enterprise Applications</h3>
          <p>
            Robust backend-oriented solutions for businesses that need reliable application design and future scalability.
          </p>
          <ul class="list-check">
            <li>Java-based business applications</li>
            <li>Structured backend logic and modules</li>
            <li>Database-driven systems</li>
            <li>Maintainable architecture approach</li>
          </ul>
          <a class="text-link" href="contact.php">Talk About Your Java Project</a>
        </article>

        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">🌐</div>
          <h3>Business Website Design & Development</h3>
          <p>
            Professional websites for service businesses, institutions, and product/service brands that need trust and lead generation.
          </p>
          <ul class="list-check">
            <li>Responsive multi-page websites</li>
            <li>Service-focused messaging structure</li>
            <li>Lead capture forms and CTA flows</li>
            <li>SEO-friendly page structure</li>
          </ul>
          <a class="text-link" href="contact.php">Get a Website Quote</a>
        </article>

        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">🔄</div>
          <h3>Process Digitization & Workflow Improvement</h3>
          <p>
            Move from manual operations to digital tracking using practical process design, templates, and software solutions.
          </p>
          <ul class="list-check">
            <li>Requirement discovery sessions</li>
            <li>Current process mapping</li>
            <li>Digital workflow recommendation</li>
            <li>Implementation support roadmap</li>
          </ul>
          <a class="text-link" href="contact.php">Plan Your Digitization</a>
        </article>

        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">🏢</div>
          <h3>Domain-Specific Product / Module Customization</h3>
          <p>
            Use domain-oriented solution concepts such as legal and finance-related modules, customized for your operational needs.
          </p>
          <ul class="list-check">
            <li>Advocate office workflow support (placeholder)</li>
            <li>Micro-finance / society process modules (placeholder)</li>
            <li>Business-specific feature adaptation</li>
            <li>Phased implementation approach</li>
          </ul>
          <a class="text-link" href="products.php">Explore Product Options</a>
        </article>

        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">📈</div>
          <h3>SEO & Digital Consulting for Small Businesses</h3>
          <p>
            Improve discoverability and enquiry quality through practical website structure, content, and local search improvements.
          </p>
          <ul class="list-check">
            <li>Website audit and improvement recommendations</li>
            <li>Basic on-page SEO guidance</li>
            <li>Service page structure strategy</li>
            <li>Lead-focused content planning</li>
          </ul>
          <a class="text-link" href="contact.php">Talk About Digital Growth</a>
        </article>
      </div>
    </div>
  </section>

  <!-- Who We Work With -->
  <section class="section">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Who We Work With</p>
        <h2>Designed for Practical Business Use Cases</h2>
        <p>
          Tawa Technology solutions are especially useful for businesses and organizations that want practical implementation support,
          not over-engineered systems.
        </p>
      </div>

      <div class="card-grid card-grid--3">
        <article class="feature-card">
          <h3>Small & Medium Businesses</h3>
          <p>
            Service businesses, growing teams, and process-driven companies that need software, websites, or digitization support.
          </p>
        </article>

        <article class="feature-card">
          <h3>Professional Offices</h3>
          <p>
            Legal, consulting, and office-based practices that need records, workflows, and coordination support.
          </p>
        </article>

        <article class="feature-card">
          <h3>Institutions & Training Organizations</h3>
          <p>
            Organizations that need websites, internal workflows, student-related systems, or digital process improvement.
          </p>
        </article>

        <article class="feature-card">
          <h3>Finance / Society Operations</h3>
          <p>
            Member-focused and transaction-based operations that need structured data management and reporting support.
          </p>
        </article>

        <article class="feature-card">
          <h3>Startups & New Ventures</h3>
          <p>
            Early-stage businesses that need MVP websites, operational tools, or structured software planning.
          </p>
        </article>

        <article class="feature-card">
          <h3>Custom Requirement Projects</h3>
          <p>
            Businesses with unique workflows where off-the-shelf tools are not the right fit.
          </p>
        </article>
      </div>
    </div>
  </section>

  <!-- Process -->
  <section class="section section--alt" id="process">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">How We Work</p>
        <h2>Simple, Clear Process for Software Projects</h2>
        <p>
          We keep the process transparent so business owners and teams can understand the scope, decisions, and next steps.
        </p>
      </div>

      <div class="process-grid">
        <article class="process-step">
          <span class="process-step__num">01</span>
          <h3>Requirement Discussion</h3>
          <p>
            We understand your business process, pain points, goals, and expected outcomes.
          </p>
        </article>

        <article class="process-step">
          <span class="process-step__num">02</span>
          <h3>Scope & Solution Planning</h3>
          <p>
            We define the solution approach, modules, priorities, and implementation phases.
          </p>
        </article>

        <article class="process-step">
          <span class="process-step__num">03</span>
          <h3>Design & Development</h3>
          <p>
            We build the solution with regular review points and practical feedback alignment.
          </p>
        </article>

        <article class="process-step">
          <span class="process-step__num">04</span>
          <h3>Testing & Review</h3>
          <p>
            Validate workflows, fix issues, and confirm operational fit before go-live.
          </p>
        </article>

        <article class="process-step">
          <span class="process-step__num">05</span>
          <h3>Deployment / Handover</h3>
          <p>
            Launch with clear usage guidance and required setup support.
          </p>
        </article>

        <article class="process-step">
          <span class="process-step__num">06</span>
          <h3>Support & Improvement</h3>
          <p>
            Enhance modules in phases as your business grows or processes evolve.
          </p>
        </article>
      </div>
    </div>
  </section>

  <!-- Featured Product Connection -->
  <section class="section" id="related-products">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Domain-Focused Capability</p>
        <h2>Built on Real Use Cases and Product Thinking</h2>
        <p>
          Our software services are strengthened by domain-oriented product concepts and implementation experience.
        </p>
      </div>

      <div class="product-grid">
        <article class="product-card">
          <img src="assets/img/advocate_diary_legal_domain.webp" alt="Advocate Diary product" />
          <div class="product-card__body">
            <span class="pill">Legal Domain</span>
            <h3>Advocate Diary</h3>
            <p>
              A legal-office-oriented solution concept for managing records, tasks, and day-to-day coordination.
            </p>
            <div class="card-actions">
              <a class="btn btn--secondary btn--sm" href="contact.php">Request Demo</a>
              <a class="text-link" href="products.php#advocate-diary">Learn More</a>
            </div>
          </div>
        </article>

        <article class="product-card">
          <img src="assets/img/MicroFinanceSocietyManagement_finance.webp" alt="Micro Finance solution" />
          <div class="product-card__body">
            <span class="pill">Finance / Society</span>
            <h3>Micro Finance / Society Management</h3>
            <p>
              A structured system approach for member records, transactions, and process management.
            </p>
            <div class="card-actions">
              <a class="btn btn--secondary btn--sm" href="/cotact.php">Discuss Requirement</a>
              <a class="text-link" href="products.php#micro-finance">Learn More</a>
            </div>
          </div>
        </article>

        <article class="product-card">
          <img src="assets/img/CustomBusinessApplication_custom_build.webp" alt="Placeholder screenshot for custom business app" />
          <div class="product-card__body">
            <span class="pill">Custom Build</span>
            <h3>Custom Business Applications</h3>
            <p>
              Need a solution built around your process? We design custom software based on your real workflow.
            </p>
            <div class="card-actions">
              <a class="btn btn--secondary btn--sm" href="contact.php">Request a Quote</a>
              <a class="text-link" href="contact.php">Talk to an Expert</a>
            </div>
          </div>
        </article>
      </div>
    </div>
  </section>

  <!-- Case Studies Preview -->
  <section class="section section--alt" id="software-case-studies">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Case Studies / Projects</p>
        <h2>Selected Business Use Cases</h2>
      </div>

      <div class="card-grid card-grid--3">
        <article class="case-card">
          <img src="assets/img/Business_process_digitization.webp" alt="Placeholder image for case study 1" />
          <div class="case-card__body">
            <h3>Business Process Digitization</h3>
            <p><strong>Problem:</strong> Manual records and inconsistent reporting.</p>
            <p><strong>Solution:</strong> Workflow-oriented digital system structure.</p>
            <p><strong>Outcome:</strong> Better process clarity and information visibility.</p>
            <a class="text-link" href="case-studies.php">View Case Studies</a>
          </div>
        </article>

        <article class="case-card">
          <img src="assets/img/Professional_Services_Website.webp" alt="Placeholder image for case study 2" />
          <div class="case-card__body">
            <h3>Professional Services Website</h3>
            <p><strong>Problem:</strong> Weak online credibility and poor lead flow.</p>
            <p><strong>Solution:</strong> Conversion-focused responsive website structure.</p>
            <p><strong>Outcome:</strong> Improved service clarity and enquiry readiness.</p>
            <a class="text-link" href="case-studies.php">View Case Studies</a>
          </div>
        </article>

        <article class="case-card">
          <img src="assets/img/Custom_Workflow_Application.webp" alt="Placeholder image for case study 3" />
          <div class="case-card__body">
            <h3>Custom Workflow Application</h3>
            <p><strong>Problem:</strong> Existing tools did not fit the process.</p>
            <p><strong>Solution:</strong> Requirement-based custom module design.</p>
            <p><strong>Outcome:</strong> Better process alignment and usability.</p>
            <a class="text-link" href="case-studies.php">View Case Studies</a>
          </div>
        </article>
      </div>

      <div class="cta-inline">
        <a class="btn btn--secondary" href="case-studies.php">View Case Studies</a>
        <a class="btn btn--primary" href="contact.php">Discuss Similar Requirement</a>
      </div>
    </div>
  </section>

  <!-- Engagement Models -->
  <section class="section" id="engagement-models">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Engagement Model</p>
        <h2>Flexible Ways to Work With Tawa Technology</h2>
        <p>
          Depending on your requirement and readiness, we can start with consultation, a scoped project, or phased development.
        </p>
      </div>

      <div class="card-grid card-grid--3">
        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">📝</div>
          <h3>Requirement Consultation</h3>
          <p>
            Best if you know the problem but need help defining the right software or website approach.
          </p>
          <ul class="list-check">
            <li>Requirement discussion</li>
            <li>Problem-to-solution mapping</li>
            <li>Scope direction (placeholder)</li>
          </ul>
        </article>

        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">🚀</div>
          <h3>Project-Based Development</h3>
          <p>
            Ideal for businesses ready to start a website, custom application, or digitization implementation.
          </p>
          <ul class="list-check">
            <li>Defined scope and deliverables</li>
            <li>Milestone-based execution</li>
            <li>Review and handover</li>
          </ul>
        </article>

        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">📦</div>
          <h3>Phased Improvement / Expansion</h3>
          <p>
            Start with essential modules and expand based on feedback, usage, and business growth.
          </p>
          <ul class="list-check">
            <li>MVP / initial rollout</li>
            <li>Feature enhancement phases</li>
            <li>Continuous improvement support</li>
          </ul>
        </article>
      </div>
    </div>
  </section>

  <!-- FAQ -->
  <section class="section section--alt" id="software-faq">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Software Solutions FAQ</p>
        <h2>Frequently Asked Questions (Business Clients)</h2>
        <p>
          These answers help clarify common questions before we start a discussion. Replace placeholder wording as needed later.
        </p>
      </div>

      <div class="faq-list">
        <details>
          <summary>What types of software projects do you handle?</summary>
          <p>
            We support custom web applications, business websites, process digitization solutions, Java-oriented backend applications, and domain-specific solution concepts.
          </p>
        </details>

        <details>
          <summary>Can you build a custom solution for my exact workflow?</summary>
          <p>
            Yes. We begin with requirement discussion and process understanding, then propose a practical solution approach aligned with your workflow and priorities.
          </p>
        </details>

        <details>
          <summary>How do you estimate project cost and timeline?</summary>
          <p>
            Cost and timeline depend on scope, complexity, number of modules, and integration needs. We typically estimate after a requirement discussion and scope definition.
          </p>
        </details>

        <details>
          <summary>Do you provide support after project delivery?</summary>
          <p>
            Yes. Support and enhancement options can be planned based on your requirement, project type, and expected usage.
          </p>
        </details>

        <details>
          <summary>Can you improve an existing website or software instead of building from scratch?</summary>
          <p>
            In many cases, yes. We can review your current setup and suggest whether improvement, redesign, or rebuild is the better option.
          </p>
        </details>

        <details>
          <summary>What is the best way to start the discussion?</summary>
          <p>
            The fastest way is WhatsApp or a direct call. You can also submit your requirement through the contact form and we’ll follow up.
          </p>
        </details>
      </div>
    </div>
  </section>

  <!-- Final CTA + Enquiry -->
  <section class="section contact-section" id="contact-cta">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Let’s Discuss Your Requirement</p>
        <h2>Ready to Digitize a Process, Build a Website, or Develop a Custom Application?</h2>
        <p>
          Share your requirement and we’ll guide you toward a practical solution path — from consultation to development and phased improvements.
        </p>
      </div>

      <div class="contact-grid">
        <div class="contact-card">
          <h3>Quick Contact Options</h3>
          <ul class="contact-list">
            <li><strong>Phone:</strong> <a href="tel:+918799996171">+91 8799996171</a></li>
            <li><strong>WhatsApp:</strong> <a href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">Start WhatsApp Chat</a></li>
            <li><strong>Email:</strong> <a href="mailto:info@tawatechnology.com">info@tawatechnology.com</a></li>
            <li><strong>Location:</strong> Nagpur, India (Placeholder address)</li>
            <li><strong>Preferred First Step:</strong> 10–15 minute requirement discussion (placeholder)</li>
          </ul>

          <div class="contact-actions">
            <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">Call / WhatsApp Now</a>
            <a class="btn btn--secondary" href="contact.php">Talk to an Expert</a>
          </div>
        </div>

        <form class="contact-form" action="#" method="post" novalidate>
          <h3>Send a Software Requirement Enquiry</h3>

          <div class="form-row">
            <label for="companyName">Company / Organization Name *</label>
            <input type="text" id="companyName" name="companyName" placeholder="Enter company name" required />
          </div>

          <div class="form-row form-row--2">
            <div>
              <label for="contactPerson">Contact Person *</label>
              <input type="text" id="contactPerson" name="contactPerson" placeholder="Your name" required />
            </div>
            <div>
              <label for="businessPhone">Phone / WhatsApp *</label>
              <input type="tel" id="businessPhone" name="businessPhone" placeholder="+91 XXXXX XXXXX" required />
            </div>
          </div>

          <div class="form-row form-row--2">
            <div>
              <label for="businessEmail">Email *</label>
              <input type="email" id="businessEmail" name="businessEmail" placeholder="you@company.com" required />
            </div>
            <div>
              <label for="serviceType">Service Needed *</label>
              <select id="serviceType" name="serviceType" required>
                <option value="">Select service</option>
                <option value="custom-web-app">Custom Web Application</option>
                <option value="java-solution">Java / Enterprise Solution</option>
                <option value="business-website">Business Website</option>
                <option value="process-digitization">Process Digitization</option>
                <option value="product-customization">Product / Module Customization</option>
                <option value="seo-consulting">SEO / Digital Consulting</option>
                <option value="not-sure">Not Sure Yet</option>
              </select>
            </div>
          </div>

          <div class="form-row">
            <label for="projectStage">Project Stage (Optional)</label>
            <select id="projectStage" name="projectStage">
              <option value="">Select current stage</option>
              <option value="idea-stage">Idea / Need Identification</option>
              <option value="requirements-discussed">Requirements Partially Defined</option>
              <option value="vendor-comparison">Comparing Vendors / Options</option>
              <option value="ready-to-start">Ready to Start Project</option>
              <option value="existing-system-improvement">Improve Existing System</option>
            </select>
          </div>

          <div class="form-row">
            <label for="businessMessage">Requirement Details *</label>
            <textarea id="businessMessage" name="businessMessage" rows="6" placeholder="Tell us about your business process, current problem, and what you want to improve..." required></textarea>
          </div>

          <div class="form-row checkbox-row">
            <input type="checkbox" id="businessConsent" name="businessConsent" required />
            <label for="businessConsent">I agree to be contacted by Tawa Technology regarding this business enquiry.</label>
          </div>

          <button type="submit" class="btn btn--primary">Send Enquiry</button>
          <p class="form-note">
            Placeholder form setup. Connect later to Formspree, Netlify Forms, or PHP mailer on your hosting.
          </p>
        </form>
      </div>
    </div>
  </section>
</main>

  <!-- Footer -->
  <footer class="site-footer">
    <div class="container footer__grid">
      <div class="footer__col footer__col--brand">
        <a href="index.php" class="brand brand--footer">
          <img src="assets/img/logo.webp" alt="Tawa Technology logo" class="brand__logo" />
          <div class="brand__text">
            <span class="brand__name">Tawa Technology</span>
            <span class="brand__tagline">Empowering Businesses &amp; Students</span>
          </div>
        </a>

        <p class="footer__about">
          Tawa Technology helps businesses digitize operations through practical software solutions and helps students build job-ready skills through project-based IT training.
        </p>

        <div class="footer__quick-contact">
          <a href="tel:+918799996171">📞 +91 8799996171</a>
          <a href="mailto:info@tawatechnology.com">✉️ info@tawatechnology.com</a>
          <a href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">💬 WhatsApp Chat</a>
          <span>📍 Nagpur, India</span>
        </div>
      </div>

      <div class="footer__col">
        <h3>Software Solutions</h3>
        <ul>
          <li><a href="/software.php">Custom Web Applications</a></li>
          <li><a href="/software.php">Java / Enterprise Solutions</a></li>
          <li><a href="/software.php">Business Websites</a></li>
          <li><a href="/software.php">Process Digitization</a></li>
          <li><a href="/software.php">SEO & Digital Consulting</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Products</h3>
        <ul>
          <li><a href="products.php#advocate-diary">Advocate Diary</a></li>
          <li><a href="products.php#micro-finance">Micro Finance Management</a></li>
          <li><a href="products.php#custom-apps">Custom Business Apps</a></li>
          <li><a href="products.php">Product Demo Request</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Training & Courses</h3>
        <ul>
          <li><a href="training.php#java-full-stack">Java Full Stack</a></li>
          <li><a href="training.php#core-java">Core Java</a></li>
          <li><a href="training.php#sql-powerbi">SQL / Power BI</a></li>
          <li><a href="training.php#web-development">Web Development</a></li>
          <li><a href="training.php#fees">Course Fees</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Company</h3>
        <ul>
          <li><a href="about.php">About Tawa Technology</a></li>
          <li><a href="case-studies.php">Case Studies</a></li>
          <li><a href="blog.php">Resources / Blog</a></li>
          <li><a href="faq.php">FAQ</a></li>
          <li><a href="contact.php">Contact / Enquiry</a></li>
        </ul>
      </div>
    </div>

    <div class="container footer__bottom">
      <p>© <span id="year"></span> Tawa Technology. All rights reserved.</p>
      <div class="footer__links">
        <a href="privacy-policy.php">Privacy Policy</a>
        <a href="terms.php">Terms</a>
        <a href="contact.php">Contact</a>
      </div>
    </div>
  </footer>

  <!-- Mobile Sticky CTA Bar -->
  <div class="mobile-cta" role="region" aria-label="Quick contact actions">
    <a class="mobile-cta__btn" href="tel:+918799996171" aria-label="Call Tawa Technology">
      📞 Call
    </a>
    <a class="mobile-cta__btn mobile-cta__btn--whatsapp"
      href="https://wa.me/918799996171"
      target="_blank" rel="noopener noreferrer"
      aria-label="WhatsApp Tawa Technology">
      WhatsApp
    </a>
  </div>
  <script src="assets/js/main.js"></script>
  </body>

  </html>