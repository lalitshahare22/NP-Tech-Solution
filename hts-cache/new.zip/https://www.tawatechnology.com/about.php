<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>About Us | Tawa Technology | Software Solutions &amp; Real-Time IT Training</title>
  <meta name="description" content="Learn about Tawa Technology—based in Nagpur, delivering practical software development, business digitization, and project-based IT training for students and professionals." />
  <meta name="theme-color" content="#003399" />

  <!-- Open Graph (basic, reusable) -->
  <meta property="og:title" content="About Us | Tawa Technology | Software Solutions &amp; Real-Time IT Training" />
  <meta property="og:description" content="Learn about Tawa Technology—based in Nagpur, delivering practical software development, business digitization, and project-based IT training for students and professionals." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://www.tawatechnology.com/" />
  <meta property="og:image" content="assets/img/hero-placeholder.jpg" />

  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Poppins:wght@600;700;800&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="assets/css/style.css" />
</head>
<body>
  <a class="skip-link" href="#main-content">Skip to content</a>

  <!-- Top Utility Bar -->
  <div class="topbar topbar--enhanced">
    <div class="container topbar__inner">
      <div class="topbar__left">
        <span class="topbar__item">📍 Nagpur, India</span>
        <a class="topbar__item" href="tel:+918799996171">📞 +91 8799996171</a>
        <a class="topbar__item" href="mailto:info@tawatechnology.com">✉️ info@tawatechnology.com</a>
      </div>
      <div class="topbar__right">
        <a class="topbar__pill" href="contact.php">Enquiry Form</a>
        <a class="topbar__pill topbar__pill--whatsapp" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">WhatsApp</a>
      </div>
    </div>
  </div>

  <!-- Main Header -->
  <header class="site-header" id="site-header">
    <div class="container header__inner">
      <a href="index.php" class="brand" aria-label="Tawa Technology home">
        <img src="assets/img/logo.webp" alt="Tawa Technology logo" class="brand__logo" />
        <div class="brand__text">
          <span class="brand__name">Tawa Technology</span>
          <span class="brand__tagline">Empowering Businesses &amp; Students</span>
        </div>
      </a>

      <button
        class="nav-toggle"
        id="navToggle"
        aria-expanded="false"
        aria-controls="primaryNav"
        aria-label="Open navigation menu"
      >
        <span></span>
        <span></span>
        <span></span>
      </button>

      <nav class="primary-nav" id="primaryNav" aria-label="Primary navigation">
        <ul class="menu">
          <li><a class="" href="index.php">Home</a></li>

          <li><a class="" href="software.php">Software Solutions</a></li>

          <!-- Dropdown-ready item -->
          <li class="has-dropdown">
            <button class="menu-btn " type="button" aria-expanded="false">
              Products
              <span class="caret" aria-hidden="true">▾</span>
            </button>
            <div class="dropdown" role="menu" aria-label="Products submenu">
              <a href="products.php">All Products</a>
              <a href="products.php#advocate-diary">Advocate Diary</a>
              <a href="products.php#micro-finance">Micro Finance</a>
              <a href="products.php#custom-apps">Custom Business Apps</a>
            </div>
          </li>

          <li class="has-dropdown">
            <button class="menu-btn " type="button" aria-expanded="false">
              Training
              <span class="caret" aria-hidden="true">▾</span>
            </button>
            <div class="dropdown" role="menu" aria-label="Training submenu">
              <a href="training.php">All Courses</a>
              <a href="training.php#java-full-stack">Java Full Stack</a>
              <a href="training.php#core-java">Core Java</a>
              <a href="training.php#sql-powerbi">SQL / Power BI</a>
              <a href="training.php#web-development">Web Development</a>
            </div>
          </li>

          <li><a class="" href="case-studies.php">Case Studies</a></li>
          <li><a class="is-active" href="about.php">About</a></li>
          <li><a class="" href="blog.php">Resources</a></li>
          <li><a class="" href="contact.php">Contact</a></li>
        </ul>

        <div class="nav-cta nav-cta--desktop">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">
            Call / WhatsApp Now
          </a>
        </div>
      </nav>
    </div>
  </header>
<main id="main-content">
  <!-- Hero -->
  <section class="section hero hero--inner">
    <div class="container hero__grid">
      <div class="hero__content">
        <p class="eyebrow">About Tawa Technology</p>
        <h1>Empowering Businesses & Students with Practical Technology</h1>
        <p class="hero__lead">
          Tawa Technology is based in Nagpur, India. We work at the intersection of
          <strong>software development</strong> and <strong>real-time IT training</strong>—helping businesses digitize operations and helping learners build job-ready skills through practical learning.
        </p>

        <div class="hero__actions">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">
            Call / WhatsApp Now
          </a>
          <a class="btn btn--secondary" href="#about-enquiry">Talk to an Expert</a>
        </div>

        <ul class="hero__trust">
          <li>Workflow-first software solutions</li>
          <li>Project-oriented training approach</li>
          <li>Transparent, practical execution</li>
        </ul>
      </div>

      <div class="hero__visual">
        <img src="assets/img/EmpoweringBusinesses_StudentswithPracticalTechnology.webp" alt="Placeholder image representing Tawa Technology team and work culture" />
      </div>
    </div>
  </section>

  <!-- Quick Identity Strip -->
  <section class="section section--alt section--compact">
    <div class="container">
      <div class="about-kpi">
        <div class="about-kpi__item">
          <p class="eyebrow">Based In</p>
          <h3>Nagpur, India</h3>
          <p class="muted">Local presence + practical support</p>
        </div>

        <div class="about-kpi__item">
          <p class="eyebrow">Focus</p>
          <h3>Software + Training</h3>
          <p class="muted">Solutions for businesses + skills for learners</p>
        </div>

        <div class="about-kpi__item">
          <p class="eyebrow">Approach</p>
          <h3>Practical Implementation</h3>
          <p class="muted">Less theory. More outcomes.</p>
        </div>

        <div class="about-kpi__item">
          <p class="eyebrow">Primary CTA</p>
          <h3>Call / WhatsApp</h3>
          <p class="muted">Fastest way to start a discussion</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Our Story -->
  <section class="section" id="our-story">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Our Story</p>
        <h2>Why Tawa Technology Exists</h2>
        <p>
          Many businesses want digitization but don’t know how to start. Many students want jobs but don’t get enough practical exposure.
          Tawa Technology exists to solve both problems with a practical, outcome-oriented approach.
        </p>
      </div>

      <div class="two-col">
        <div class="panel">
          <h3>For Businesses</h3>
          <p>
            We help businesses build professional online presence and digitize workflows using practical software solutions—
            from business websites to custom web applications and domain-specific systems.
          </p>
          <ul class="list-check">
            <li>Requirement-first implementation</li>
            <li>Workflow clarity + reporting readiness</li>
            <li>Phased delivery for better control</li>
          </ul>
          <div class="card-actions">
            <a class="btn btn--secondary btn--sm" href="software.php">Explore Software Solutions</a>
            <a class="text-link" href="case-studies.php">View Case Studies</a>
          </div>
        </div>

        <div class="panel">
          <h3>For Students & Professionals</h3>
          <p>
            We provide real-time, project-based training that helps learners build strong fundamentals and practical confidence—
            especially in Java, SQL, Power BI, and Web Development.
          </p>
          <ul class="list-check">
            <li>Structured learning paths</li>
            <li>Practical exercises and project thinking</li>
            <li>Career-oriented guidance</li>
          </ul>
          <div class="card-actions">
            <a class="btn btn--secondary btn--sm" href="training.php">Explore Training Programs</a>
            <a class="text-link" href="training.php#fees">View Fee Structure</a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Mission / Vision / Values -->
  <section class="section section--alt" id="mission-vision">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Mission & Values</p>
        <h2>What We Stand For</h2>
        <p>
          Our work is guided by practical outcomes, clean execution, and a strong focus on clarity—both in software and in training.
        </p>
      </div>

      <div class="card-grid card-grid--3">
        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">🎯</div>
          <h3>Mission</h3>
          <p>
            To empower businesses and learners through practical technology—building solutions and skills that create real outcomes.
          </p>
        </article>

        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">🔭</div>
          <h3>Vision</h3>
          <p>
            To be a trusted technology partner in Nagpur and beyond—known for reliability, clarity, and real-world impact.
          </p>
        </article>

        <article class="info-card">
          <div class="icon-badge" aria-hidden="true">🧭</div>
          <h3>Core Values</h3>
          <ul class="list-check">
            <li>Clarity over confusion</li>
            <li>Practical outcomes</li>
            <li>Consistency and trust</li>
            <li>Continuous improvement</li>
          </ul>
        </article>
      </div>
    </div>
  </section>

  <!-- What We Do (3 pillars) -->
  <section class="section" id="what-we-do">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">What We Do</p>
        <h2>Three Pillars of Tawa Technology</h2>
        <p>
          The business is designed to serve both clients and learners—keeping the brand consistent, practical, and outcomes-driven.
        </p>
      </div>

      <div class="card-grid card-grid--3">
        <article class="feature-card">
          <h3>Software Development & IT Solutions</h3>
          <p>
            Custom web applications, Java solutions, business websites, and workflow-based systems to help organizations digitize operations.
          </p>
          <a class="text-link" href="software.php">Explore Software Solutions</a>
        </article>

        <article class="feature-card">
          <h3>Training & Education</h3>
          <p>
            Project-based training for students and professionals in Java Full Stack, Core Java, SQL/Power BI, and Web Development.
          </p>
          <a class="text-link" href="training.php">Explore Training Programs</a>
        </article>

        <article class="feature-card">
          <h3>Digital & Web Services</h3>
          <p>
            Website design, SEO-friendly content structure, and digital consulting for small businesses looking to build credibility and leads.
          </p>
          <a class="text-link" href="software.php#software-services">Explore Digital Services</a>
        </article>
      </div>
    </div>
  </section>

  <!-- Why Choose Us -->
  <section class="section section--alt" id="why-choose-us">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Why Choose Tawa Technology</p>
        <h2>Practical, Clear, and Trust-Oriented Execution</h2>
        <p>
          Whether you are a business owner or a student, the goal is the same: clear direction, practical work, and measurable progress.
        </p>
      </div>

      <div class="card-grid card-grid--3">
        <article class="feature-card">
          <h3>Requirement-First Thinking</h3>
          <p>We focus on your actual workflow and outcome before suggesting features or technology.</p>
        </article>

        <article class="feature-card">
          <h3>Professional Communication</h3>
          <p>Clear scope, priorities, and next steps—so you always know what’s happening.</p>
        </article>

        <article class="feature-card">
          <h3>Phased Implementation</h3>
          <p>Start small with essentials, then expand based on feedback, usage, and business growth.</p>
        </article>

        <article class="feature-card">
          <h3>Practical Training Methods</h3>
          <p>Project-based learning, structured guidance, and clarity-focused teaching style.</p>
        </article>

        <article class="feature-card">
          <h3>Strong Basics + Real Implementation</h3>
          <p>We emphasize fundamentals and real usage so solutions and skills remain stable long-term.</p>
        </article>

        <article class="feature-card">
          <h3>Support & Improvement Mindset</h3>
          <p>We help improve systems and learning paths based on real challenges and progress.</p>
        </article>
      </div>
    </div>
  </section>

  <!-- Timeline / Milestones -->
  <section class="section" id="milestones">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Milestones</p>
        <h2>Growth Timeline</h2>
      </div>

      <div class="timeline">
        <div class="timeline__item">
          <span class="timeline__dot" aria-hidden="true"></span>
          <div class="timeline__content">
            <h3>Started with a clear focus: Software + Training</h3>
            <p class="muted">Year: 2025</p>
            <p>Built initial service offerings and started training programs with practical orientation.</p>
          </div>
        </div>

        <div class="timeline__item">
          <span class="timeline__dot" aria-hidden="true"></span>
          <div class="timeline__content">
            <h3>First Product / Module-Based Solutions</h3>
            <p class="muted">Year: 2025</p>
            <p>Introduced domain-oriented products like Advocate Diary, Job Portal and Micro-finance.</p>
          </div>
        </div>

        <div class="timeline__item">
          <span class="timeline__dot" aria-hidden="true"></span>
          <div class="timeline__content">
            <h3>Expanded Training Programs</h3>
            <p class="muted">Year: 2026</p>
            <p>Added structured programs in Java Full Stack, SQL/Power BI, and Web Development.</p>
          </div>
        </div>

        <div class="timeline__item">
          <span class="timeline__dot" aria-hidden="true"></span>
          <div class="timeline__content">
            <h3>Next Phase: More Products + Business Partnerships</h3>
            <p class="muted">Year: 2027</p>
            <p>Future plan: more domain-focused products and stronger institutional collaborations.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Founder / Team
  <section class="section section--alt" id="team">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Team</p>
        <h2>Founder / Team (Placeholder)</h2>
        <p>
          You said you don’t have a founder/team photo right now. This section is designed to work with placeholders until you add real images.
        </p>
      </div>

      <div class="team-grid">
        <article class="team-card">
          <img src="/assets/img/founder-placeholder.jpg" alt="Placeholder founder image for Tawa Technology" />
          <div class="team-card__body">
            <h3>Founder Name (Placeholder)</h3>
            <p class="muted">Role: Founder / Lead Consultant (Placeholder)</p>
            <p>
              Short founder summary placeholder: background, approach, and why you started Tawa Technology.
            </p>
          </div>
        </article>

        <article class="team-card">
          <img src="/assets/img/team-placeholder.jpg" alt="Placeholder team image for Tawa Technology" />
          <div class="team-card__body">
            <h3>Core Team (Placeholder)</h3>
            <p class="muted">Roles: Development / Training / Support</p>
            <p>
              Short team summary placeholder: how you deliver projects and training with consistent support.
            </p>
          </div>
        </article>
      </div>
    </div>
  </section>
 -->
  <!-- Final CTA + About Enquiry -->
  <section class="section contact-section" id="about-enquiry">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Let’s Connect</p>
        <h2>Want to Discuss a Project or Join a Training Program?</h2>
        <p>
          Tell us what you need. We’ll guide you toward a practical next step—software development, product demo, or training path.
        </p>
      </div>

      <div class="contact-grid">
        <div class="contact-card">
          <h3>Quick Contact Options</h3>
          <ul class="contact-list">
            <li><strong>Phone:</strong> <a href="tel:+918799996171">+91 8799996171</a></li>
            <li><strong>WhatsApp:</strong> <a href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">Start WhatsApp Chat</a></li>
            <li><strong>Email:</strong> <a href="mailto:info@tawatechnology.com">info@tawatechnology.com</a></li>
            <li><strong>Location:</strong> Nagpur, India (Placeholder address)</li>
          </ul>

          <div class="contact-actions">
            <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">Call / WhatsApp Now</a>
            <a class="btn btn--secondary" href="contact.php">Talk to an Expert</a>
          </div>
        </div>

        <form class="contact-form" action="#" method="post" novalidate>
          <h3>Send a Message</h3>

          <div class="form-row form-row--2">
            <div>
              <label for="fullName">Full Name *</label>
              <input type="text" id="fullName" name="fullName" placeholder="Your name" required />
            </div>
            <div>
              <label for="phone">Phone / WhatsApp *</label>
              <input type="tel" id="phone" name="phone" placeholder="+91 XXXXX XXXXX" required />
            </div>
          </div>

          <div class="form-row form-row--2">
            <div>
              <label for="email">Email *</label>
              <input type="email" id="email" name="email" placeholder="you@example.com" required />
            </div>
            <div>
              <label for="enquiryType">Enquiry Type *</label>
              <select id="enquiryType" name="enquiryType" required>
                <option value="">Select option</option>
                <option value="software">Software / Website</option>
                <option value="product-demo">Product Demo</option>
                <option value="training">Training / Courses</option>
                <option value="not-sure">Not Sure Yet</option>
              </select>
            </div>
          </div>

          <div class="form-row">
            <label for="message">Message *</label>
            <textarea id="message" name="message" rows="6" placeholder="Tell us what you need..." required></textarea>
          </div>

          <div class="form-row checkbox-row">
            <input type="checkbox" id="consent" name="consent" required />
            <label for="consent">I agree to be contacted by Tawa Technology regarding this enquiry.</label>
          </div>

          <button type="submit" class="btn btn--primary">Send Message</button>

        </form>
      </div>
    </div>
  </section>
</main>

  <!-- Footer -->
  <footer class="site-footer">
    <div class="container footer__grid">
      <div class="footer__col footer__col--brand">
        <a href="index.php" class="brand brand--footer">
          <img src="assets/img/logo.webp" alt="Tawa Technology logo" class="brand__logo" />
          <div class="brand__text">
            <span class="brand__name">Tawa Technology</span>
            <span class="brand__tagline">Empowering Businesses &amp; Students</span>
          </div>
        </a>

        <p class="footer__about">
          Tawa Technology helps businesses digitize operations through practical software solutions and helps students build job-ready skills through project-based IT training.
        </p>

        <div class="footer__quick-contact">
          <a href="tel:+918799996171">📞 +91 8799996171</a>
          <a href="mailto:info@tawatechnology.com">✉️ info@tawatechnology.com</a>
          <a href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">💬 WhatsApp Chat</a>
          <span>📍 Nagpur, India</span>
        </div>
      </div>

      <div class="footer__col">
        <h3>Software Solutions</h3>
        <ul>
          <li><a href="/software.php">Custom Web Applications</a></li>
          <li><a href="/software.php">Java / Enterprise Solutions</a></li>
          <li><a href="/software.php">Business Websites</a></li>
          <li><a href="/software.php">Process Digitization</a></li>
          <li><a href="/software.php">SEO & Digital Consulting</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Products</h3>
        <ul>
          <li><a href="products.php#advocate-diary">Advocate Diary</a></li>
          <li><a href="products.php#micro-finance">Micro Finance Management</a></li>
          <li><a href="products.php#custom-apps">Custom Business Apps</a></li>
          <li><a href="products.php">Product Demo Request</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Training & Courses</h3>
        <ul>
          <li><a href="training.php#java-full-stack">Java Full Stack</a></li>
          <li><a href="training.php#core-java">Core Java</a></li>
          <li><a href="training.php#sql-powerbi">SQL / Power BI</a></li>
          <li><a href="training.php#web-development">Web Development</a></li>
          <li><a href="training.php#fees">Course Fees</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Company</h3>
        <ul>
          <li><a href="about.php">About Tawa Technology</a></li>
          <li><a href="case-studies.php">Case Studies</a></li>
          <li><a href="blog.php">Resources / Blog</a></li>
          <li><a href="faq.php">FAQ</a></li>
          <li><a href="contact.php">Contact / Enquiry</a></li>
        </ul>
      </div>
    </div>

    <div class="container footer__bottom">
      <p>© <span id="year"></span> Tawa Technology. All rights reserved.</p>
      <div class="footer__links">
        <a href="privacy-policy.php">Privacy Policy</a>
        <a href="terms.php">Terms</a>
        <a href="contact.php">Contact</a>
      </div>
    </div>
  </footer>

  <!-- Mobile Sticky CTA Bar -->
  <div class="mobile-cta" role="region" aria-label="Quick contact actions">
    <a class="mobile-cta__btn" href="tel:+918799996171" aria-label="Call Tawa Technology">
      📞 Call
    </a>
    <a class="mobile-cta__btn mobile-cta__btn--whatsapp"
      href="https://wa.me/918799996171"
      target="_blank" rel="noopener noreferrer"
      aria-label="WhatsApp Tawa Technology">
      WhatsApp
    </a>
  </div>
  <script src="assets/js/main.js"></script>
  </body>

  </html>