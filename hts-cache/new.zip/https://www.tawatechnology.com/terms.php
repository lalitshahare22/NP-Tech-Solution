<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Terms &amp; Conditions | Tawa Technology</title>
  <meta name="description" content="Terms and Conditions for using the Tawa Technology website, services, products, and training programs." />
  <meta name="theme-color" content="#003399" />

  <!-- Open Graph (basic, reusable) -->
  <meta property="og:title" content="Terms &amp; Conditions | Tawa Technology" />
  <meta property="og:description" content="Terms and Conditions for using the Tawa Technology website, services, products, and training programs." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://www.tawatechnology.com/" />
  <meta property="og:image" content="assets/img/hero-placeholder.jpg" />

  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Poppins:wght@600;700;800&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="assets/css/style.css" />
</head>
<body>
  <a class="skip-link" href="#main-content">Skip to content</a>

  <!-- Top Utility Bar -->
  <div class="topbar topbar--enhanced">
    <div class="container topbar__inner">
      <div class="topbar__left">
        <span class="topbar__item">📍 Nagpur, India</span>
        <a class="topbar__item" href="tel:+918799996171">📞 +91 8799996171</a>
        <a class="topbar__item" href="mailto:info@tawatechnology.com">✉️ info@tawatechnology.com</a>
      </div>
      <div class="topbar__right">
        <a class="topbar__pill" href="contact.php">Enquiry Form</a>
        <a class="topbar__pill topbar__pill--whatsapp" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">WhatsApp</a>
      </div>
    </div>
  </div>

  <!-- Main Header -->
  <header class="site-header" id="site-header">
    <div class="container header__inner">
      <a href="index.php" class="brand" aria-label="Tawa Technology home">
        <img src="assets/img/logo.webp" alt="Tawa Technology logo" class="brand__logo" />
        <div class="brand__text">
          <span class="brand__name">Tawa Technology</span>
          <span class="brand__tagline">Empowering Businesses &amp; Students</span>
        </div>
      </a>

      <button
        class="nav-toggle"
        id="navToggle"
        aria-expanded="false"
        aria-controls="primaryNav"
        aria-label="Open navigation menu"
      >
        <span></span>
        <span></span>
        <span></span>
      </button>

      <nav class="primary-nav" id="primaryNav" aria-label="Primary navigation">
        <ul class="menu">
          <li><a class="" href="index.php">Home</a></li>

          <li><a class="" href="software.php">Software Solutions</a></li>

          <!-- Dropdown-ready item -->
          <li class="has-dropdown">
            <button class="menu-btn " type="button" aria-expanded="false">
              Products
              <span class="caret" aria-hidden="true">▾</span>
            </button>
            <div class="dropdown" role="menu" aria-label="Products submenu">
              <a href="products.php">All Products</a>
              <a href="products.php#advocate-diary">Advocate Diary</a>
              <a href="products.php#micro-finance">Micro Finance</a>
              <a href="products.php#custom-apps">Custom Business Apps</a>
            </div>
          </li>

          <li class="has-dropdown">
            <button class="menu-btn " type="button" aria-expanded="false">
              Training
              <span class="caret" aria-hidden="true">▾</span>
            </button>
            <div class="dropdown" role="menu" aria-label="Training submenu">
              <a href="training.php">All Courses</a>
              <a href="training.php#java-full-stack">Java Full Stack</a>
              <a href="training.php#core-java">Core Java</a>
              <a href="training.php#sql-powerbi">SQL / Power BI</a>
              <a href="training.php#web-development">Web Development</a>
            </div>
          </li>

          <li><a class="" href="case-studies.php">Case Studies</a></li>
          <li><a class="" href="about.php">About</a></li>
          <li><a class="" href="blog.php">Resources</a></li>
          <li><a class="" href="contact.php">Contact</a></li>
        </ul>

        <div class="nav-cta nav-cta--desktop">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">
            Call / WhatsApp Now
          </a>
        </div>
      </nav>
    </div>
  </header>
<main id="main-content">
  <section class="section hero hero--inner">
    <div class="container hero__grid">
      <div class="hero__content">
        <p class="eyebrow">Legal</p>
        <h1>Terms & Conditions</h1>
        <p class="hero__lead">
          These Terms & Conditions govern your use of the Tawa Technology website and your engagement with our services, products, and training programs.
        </p>
        <div class="hero__actions">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">Call / WhatsApp Now</a>
          <a class="btn btn--secondary" href="contact.php">Contact</a>
        </div>
        <p class="muted" style="margin-top:10px;">
          Effective Date: <strong>[DD Month YYYY]</strong> • Last Updated: <strong>[DD Month YYYY]</strong>
        </p>
      </div>

      <div class="hero__visual">
        <img src="assets/img/legal-placeholder.jpg" alt="Terms and conditions" />
      </div>
    </div>
  </section>

  <section class="section">
    <div class="container content-page">

      <div class="notice-box">
        <strong>Note:</strong> This is a general terms template. Replace placeholders and adjust based on your exact offerings and business requirements.
      </div>

      <h2>1) Acceptance of Terms</h2>
      <p>
        By accessing or using this website or by engaging with Tawa Technology (“we”, “us”, “our”), you agree to be bound by these Terms & Conditions.
        If you do not agree, please do not use the website or services.
      </p>

      <h2>2) About Our Services</h2>
      <p>Tawa Technology provides:</p>
      <ul>
        <li>Software Development & IT Solutions</li>
        <li>Training & Education programs</li>
        <li>Digital & Web Services (website, SEO, consulting)</li>
        <li>Domain-specific products and custom modules</li>
      </ul>

      <h2>3) Website Use</h2>
      <ul>
        <li>You agree not to misuse this website or attempt to disrupt its operation.</li>
        <li>You agree not to upload malicious files, spam forms, or attempt unauthorized access.</li>
        <li>We may change, suspend, or discontinue any part of the website at any time.</li>
      </ul>

      <h2>4) Enquiries, Quotes, and Project Engagement</h2>
      <ul>
        <li>Any information on this website is for general guidance only and may change.</li>
        <li>Quotes are provided based on the scope shared by the client and may change if requirements change.</li>
        <li>Project timelines are estimates and depend on scope clarity, client approvals, and dependencies.</li>
      </ul>

      <h2>5) Training Programs (General Terms)</h2>
      <ul>
        <li>Training details (batch dates, curriculum, fees) may be updated as needed.</li>
        <li>Attendance and participation are the learner’s responsibility.</li>
        <li>Training content is for educational use only; redistribution without permission is prohibited.</li>
        <li>Placement support (if mentioned) is guidance-oriented and does not guarantee job placement.</li>
      </ul>

      <h2>6) Payments</h2>
      <ul>
        <li>Payments for projects/training must be made as per agreed terms shared during confirmation.</li>
        <li>For project work, milestone payments may be required.</li>
        <li>For training, installment terms (if any) must be followed as agreed.</li>
      </ul>

      <h2>7) Intellectual Property</h2>
      <p>
        All website content, branding, and materials are owned by Tawa Technology unless otherwise stated.
        You may not copy, reproduce, or redistribute content without prior written permission.
      </p>
      <p>
        For client projects, ownership and licensing terms are defined in the project agreement/SOW (placeholder).
      </p>

      <h2>8) Third-Party Links</h2>
      <p>
        Our site may link to third-party websites (example: product login portals). We are not responsible for their content or privacy practices.
      </p>

      <h2>9) Limitation of Liability</h2>
      <p>
        To the maximum extent permitted by law, Tawa Technology is not liable for any indirect, incidental, special, or consequential damages arising from the use of this website or services.
      </p>

      <h2>10) Termination</h2>
      <p>
        We may restrict or terminate access to the website if we believe there is misuse or violation of these Terms.
      </p>

      <h2>11) Governing Law</h2>
      <p>
        These Terms are governed by the laws of India. Any disputes shall be subject to jurisdiction of courts in <strong>Nagpur, Maharashtra</strong>.
      </p>

      <h2>12) Updates to Terms</h2>
      <p>
        We may update these Terms at any time. Updates will be posted on this page with revised dates.
      </p>

      <h2>13) Contact</h2>
      <ul>
        <li><strong>Email:</strong> <a href="mailto:info@tawatechnology.com">info@tawatechnology.com</a></li>
        <li><strong>Phone:</strong> <a href="tel:+918799996171">+91 8799996171</a></li>
        <li><strong>WhatsApp:</strong> <a href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">Chat on WhatsApp</a></li>
      </ul>

      <div class="cta-banner" style="margin-top:24px;">
        <div class="cta-banner__content">
          <p class="eyebrow">Need Clarification?</p>
          <h2>Talk to us before you start</h2>
          <p>We’ll clarify scope, fees, and next steps.</p>
        </div>
        <div class="cta-banner__actions">
          <a class="btn btn--primary" href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">WhatsApp Now</a>
          <a class="btn btn--secondary" href="contact.php">Contact</a>
        </div>
      </div>

    </div>
  </section>
</main>

  <!-- Footer -->
  <footer class="site-footer">
    <div class="container footer__grid">
      <div class="footer__col footer__col--brand">
        <a href="index.php" class="brand brand--footer">
          <img src="assets/img/logo.webp" alt="Tawa Technology logo" class="brand__logo" />
          <div class="brand__text">
            <span class="brand__name">Tawa Technology</span>
            <span class="brand__tagline">Empowering Businesses &amp; Students</span>
          </div>
        </a>

        <p class="footer__about">
          Tawa Technology helps businesses digitize operations through practical software solutions and helps students build job-ready skills through project-based IT training.
        </p>

        <div class="footer__quick-contact">
          <a href="tel:+918799996171">📞 +91 8799996171</a>
          <a href="mailto:info@tawatechnology.com">✉️ info@tawatechnology.com</a>
          <a href="https://wa.me/918799996171" target="_blank" rel="noopener noreferrer">💬 WhatsApp Chat</a>
          <span>📍 Nagpur, India</span>
        </div>
      </div>

      <div class="footer__col">
        <h3>Software Solutions</h3>
        <ul>
          <li><a href="/software.php">Custom Web Applications</a></li>
          <li><a href="/software.php">Java / Enterprise Solutions</a></li>
          <li><a href="/software.php">Business Websites</a></li>
          <li><a href="/software.php">Process Digitization</a></li>
          <li><a href="/software.php">SEO & Digital Consulting</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Products</h3>
        <ul>
          <li><a href="products.php#advocate-diary">Advocate Diary</a></li>
          <li><a href="products.php#micro-finance">Micro Finance Management</a></li>
          <li><a href="products.php#custom-apps">Custom Business Apps</a></li>
          <li><a href="products.php">Product Demo Request</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Training & Courses</h3>
        <ul>
          <li><a href="training.php#java-full-stack">Java Full Stack</a></li>
          <li><a href="training.php#core-java">Core Java</a></li>
          <li><a href="training.php#sql-powerbi">SQL / Power BI</a></li>
          <li><a href="training.php#web-development">Web Development</a></li>
          <li><a href="training.php#fees">Course Fees</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h3>Company</h3>
        <ul>
          <li><a href="about.php">About Tawa Technology</a></li>
          <li><a href="case-studies.php">Case Studies</a></li>
          <li><a href="blog.php">Resources / Blog</a></li>
          <li><a href="faq.php">FAQ</a></li>
          <li><a href="contact.php">Contact / Enquiry</a></li>
        </ul>
      </div>
    </div>

    <div class="container footer__bottom">
      <p>© <span id="year"></span> Tawa Technology. All rights reserved.</p>
      <div class="footer__links">
        <a href="privacy-policy.php">Privacy Policy</a>
        <a href="terms.php">Terms</a>
        <a href="contact.php">Contact</a>
      </div>
    </div>
  </footer>

  <!-- Mobile Sticky CTA Bar -->
  <div class="mobile-cta" role="region" aria-label="Quick contact actions">
    <a class="mobile-cta__btn" href="tel:+918799996171" aria-label="Call Tawa Technology">
      📞 Call
    </a>
    <a class="mobile-cta__btn mobile-cta__btn--whatsapp"
      href="https://wa.me/918799996171"
      target="_blank" rel="noopener noreferrer"
      aria-label="WhatsApp Tawa Technology">
      WhatsApp
    </a>
  </div>
  <script src="assets/js/main.js"></script>
  </body>

  </html>